#!/usr/bin/env python
"""
Generate a small FAKE ROSMAP/STRING/GWAS-Catalog dataset in <root>/raw/ so that the full pipeline can be
smoke-tested without Synapse access.  The numbers it produces are meaningless biologically.

    python make_synthetic_data.py --root data_demo
    python stage1_preprocessing.py --root data_demo --proteomics synthetic_proteomics.csv.gz \
           --map-file synthetic_sample_map.csv --map-col-sample SampleID --map-col-id individualID --map-col-batch Batch
"""
import argparse
import gzip
from pathlib import Path

import numpy as np
import pandas as pd


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default="data_demo")
    ap.add_argument("--n-genes", type=int, default=900)
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()
    rng = np.random.default_rng(a.seed)
    raw = Path(a.root) / "raw"
    raw.mkdir(parents=True, exist_ok=True)

    G = a.n_genes
    genes = [f"GENE{i:04d}" for i in range(G)]
    pos_genes = ["APP", "PSEN1", "PSEN2"] + [f"GENE{i:04d}" for i in range(0, 60)]       # 63 candidate positives
    genes[:63] = pos_genes
    genes = list(dict.fromkeys(genes))
    G = len(genes)
    is_pos = np.array([g in pos_genes for g in genes])

    # ---- clinical -----------------------------------------------------------------------------------------------
    n_ind = 480
    cogdx = rng.choice([1, 2, 3, 4, 5], size=n_ind, p=[.34, .06, .06, .44, .10])
    clin = pd.DataFrame({
        "projid": rng.choice(np.arange(10_000_000, 99_999_999), n_ind, replace=False),
        "individualID": [f"R{rng.integers(1_000_000, 9_999_999)}" for _ in range(n_ind)],
        "msex": rng.integers(0, 2, n_ind),
        "age_death": np.where(rng.random(n_ind) < .3, "90+", np.round(rng.normal(86, 5, n_ind), 1).astype(str)),
        "pmi": np.round(rng.gamma(3, 3, n_ind), 1),
        "braaksc": np.where(cogdx == 4, rng.integers(3, 7, n_ind), rng.integers(0, 4, n_ind)),
        "ceradsc": np.where(cogdx == 4, rng.integers(1, 3, n_ind), rng.integers(2, 5, n_ind)),
        "cogdx": cogdx,
    })
    clin = clin.drop_duplicates("individualID")
    clin.to_csv(raw / "ROSMAP_clinical.csv", index=False)
    n_ind = len(clin)

    # ---- expression with AD-specific correlation modules --------------------------------------------------------
    n_mod, mod_of = 25, rng.integers(0, 25, G)
    is_ad = (clin.cogdx.values == 4)
    batch_id = rng.integers(1, 31, n_ind)
    X = np.zeros((G, n_ind))
    factors = rng.normal(size=(n_mod, n_ind))
    for g in range(G):
        load = rng.uniform(0.2, 0.5) + (0.8 if (mod_of[g] < 12) else 0.0) * is_ad          # stronger co-regulation in AD
        X[g] = load * factors[mod_of[g]] + rng.normal(size=n_ind) * 1.0
        if is_pos[g]:
            X[g] += 0.5 * is_ad                                                              # up-regulated in AD
    X += rng.normal(scale=0.5, size=(1, n_ind)) * 0 + (batch_id * 0.05)[None, :]            # mild batch shift
    X += 20
    sparse_genes = rng.random(G) < 0.15
    mask = rng.random(X.shape) < np.where(sparse_genes, 0.35, 0.03)[:, None]
    X[mask] = np.nan
    uni = [f"P{100000 + i}" for i in range(G)]
    cols = [f"b{b}.{126 + i % 10}.{i}" for i, b in enumerate(batch_id)]
    mat = pd.DataFrame(X, index=[f"{g}|{u}" for g, u in zip(genes, uni)], columns=cols)
    mat.to_csv(raw / "synthetic_proteomics.csv.gz")
    pd.DataFrame({"SampleID": cols, "individualID": clin.individualID.values, "Batch": [f"b{b}" for b in batch_id]}
                 ).to_csv(raw / "synthetic_sample_map.csv", index=False)

    # ---- STRING ---------------------------------------------------------------------------------------------------
    ensp = {g: f"9606.ENSP{i:011d}" for i, g in enumerate(genes)}
    w = np.where(is_pos, 6.0, 1.0)
    w = w / w.sum()
    pairs = set()
    while len(pairs) < G * 14:
        i = rng.choice(G, p=w)
        j = rng.choice(np.where(mod_of == mod_of[i])[0]) if rng.random() < .6 else rng.choice(G, p=w)
        if i != j:
            pairs.add((min(i, j), max(i, j)))
    rows = []
    for i, j in pairs:
        s = int(np.clip(rng.normal(780, 100), 400, 999))
        rows += [(ensp[genes[i]], ensp[genes[j]], s), (ensp[genes[j]], ensp[genes[i]], s)]
    with gzip.open(raw / "9606.protein.links.v12.0.txt.gz", "wt") as f:
        f.write("protein1 protein2 combined_score\n")
        f.writelines(f"{a_} {b_} {c_}\n" for a_, b_, c_ in rows)
    info = pd.DataFrame({"#string_protein_id": [ensp[g] for g in genes], "preferred_name": genes,
                         "protein_size": 300, "annotation": "synthetic"})
    info.to_csv(raw / "9606.protein.info.v12.0.txt.gz", sep="\t", index=False)

    # ---- GWAS catalog (fake) -------------------------------------------------------------------------------------
    gw = []
    for g in pos_genes[3:]:
        gw.append(("Alzheimer disease", "Alzheimer disease", g, g, 1e-9, 0))
    for g in [f"GENE{i:04d}" for i in range(60, 75)]:                 # suggestive only -> excluded from both classes
        gw.append(("Alzheimer disease", "Alzheimer disease", g, g, 1e-6, 0))
    pd.DataFrame(gw, columns=["DISEASE/TRAIT", "MAPPED_TRAIT", "MAPPED_GENE", "REPORTED GENE(S)", "P-VALUE", "INTERGENIC"]
                 ).to_csv(raw / "gwas_catalog_v1.0.2-associations_synthetic.tsv", sep="\t", index=False)
    print(f"synthetic data written to {raw}   (genes={G}, individuals={n_ind})")


if __name__ == "__main__":
    main()
