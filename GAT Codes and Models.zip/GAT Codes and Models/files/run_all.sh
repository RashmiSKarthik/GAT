#!/usr/bin/env bash
# Edit the three file names below after downloading the data (see README.md), then:  bash run_all.sh
set -euo pipefail
ROOT=data
PROT="PUT_PROTEOMICS_MATRIX_FILENAME_HERE"      # inside data/raw/
MAP="PUT_SAMPLE_METADATA_FILENAME_HERE"         # inside data/raw/  (matrix column -> individualID, batch)

python stage1_preprocessing.py --root $ROOT --proteomics "$PROT" --map-file "$MAP" --network-stats
python stage2_train.py        --root $ROOT --repeats 10 --ensemble-seeds 20
python stage3_enrichment_figures.py --root $ROOT --obo $ROOT/raw/go-basic.obo --gaf $ROOT/raw/goa_human.gaf.gz
