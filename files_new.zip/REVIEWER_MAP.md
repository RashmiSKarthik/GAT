# Reviewer comments → code

"Code" = already implemented; "Text" = needs a manuscript edit (the code produces the number you need); "Not done" = not implemented.

| Comment | Status | Where |
|---|---|---|
| R1/R3: leakage of test nodes into topology features; scaler fit on training nodes | Code | `stage4 --analysis leakfree` → `results/reviewer/leakfree_summary.csv` (3 settings: transductive, train-fit scaler, inductive with test nodes/edges masked) |
| R1: was fold-change computed over all 200 subjects? | Text | Yes (per-protein mean AD − mean control, log2). It uses expression only; no protein label enters it |
| R3.2: differential edges built on all subjects before CV | Text / Stage 5 | CV splits **proteins**, not subjects, and edge construction never sees labels, so re-deriving edges per fold would give identical edges. The real concern (subject-level overfitting) is addressed by the independent cohort in stage 5 |
| R1/R2/R3: signed-rank test on independent groups | Code | Tables 3: `stage1` (Mann–Whitney U); Table 10: `stage3` (Mann–Whitney U) |
| R1/R2: Wilcoxon on 5 folds | Code | `stage2` Table 5: Nadeau–Bengio corrected resampled t-test + 95 % CI (`--repeats 10` for 50 paired folds). Smallest possible two-sided signed-rank p with 5 pairs is 0.0625 |
| R1/R3: degree / study bias, degree-matched negatives | Code | `stage4 --analysis degree_matched` (+ balance table) and `--analysis permutation` |
| R1/R3: PU learning; 1:2, 1:5, 1:10 ratios | Code | `stage4 --analysis pu` (nnPU, prior sensitivity) and `--analysis ratios` |
| R1: Random forest / XGBoost / LightGBM baseline | Code | `stage4 --analysis trees` (RF, HistGradientBoosting; XGBoost/LightGBM if installed) |
| R1: minimum observed samples per protein | Code | `processed/stage1_report.json → qc.min_observed_per_protein` |
| R1: STRING weights in message passing? | Code | Default is the binary differential graph. `--edge-attr string` or `abs_r` feeds scores as GAT edge features |
| R1: partial correlation / graphical LASSO | **Not done** | Suggest a sensitivity analysis on the top-N most variable proteins and say so as a limitation |
| R2.3: exact edge rule, signed vs absolute | Code | `stage1 --edge-rule {abs,strengthened,positive}` (rules are defined in `differential_edges()`); report the one you use |
| R2 minor: "two-layer" vs three conv layers | Text | Two hidden multi-head GAT layers + one single-head output layer (`GAT` class) |
| R1: APP/MAPT among "novel" candidates | Code | Novel tables exclude every label-1 gene; known-gene probabilities use out-of-fold values (`oof_prob`) |
| R1: ECE 0.038 vs 0.046; precision 51.9 % vs 0.61 | Text | Pooled out-of-fold values are in `calibration.json`; Table 4 is a per-fold mean. State which one each number is |
| R1/R2: figure/table numbering, citations | Text | — |
| R3.4: external validation | Code | `stage5_external_validation.py` (held-out genes scored on an independent cohort's graph) |
| R1/R3: code and data availability | Code | This repository, `CITATION.cff`, `.zenodo` workflow in the README |
| R2.2: wording of biological claims | Text | The model scores similarity to known AD genes; candidate scores are not independent validation |

## Other inconsistencies noticed in the manuscript/supplement
* Table 3 PageRank mean (0.0021) cannot be right: PageRank sums to 1 so the mean over 5,234 nodes is 1/5,234 ≈ 1.9×10⁻⁴ (stage 1 prints this check).
* Supplementary Table S2 is titled "complete grid search" but lists 6 configurations; the Methods describe 108 (`stage2 --grid` runs all of them).
* Known-gene probabilities from the final model are in-sample (those genes were training labels).
