# GAT-AD — graph-attention prioritisation of Alzheimer's disease proteins

Code for *"Graph Attention Networks Identify Kinase-Chaperone Driver Modules in Alzheimer's Disease Proteomic Networks"*.
ROS/MAP DLPFC TMT proteomics (100 AD vs 100 control) → STRING v12.0 PPI network → disease-enriched differential network → five node
features → graph attention network (GAT) trained on 57 known AD genes vs sampled bystanders → ranked candidates.

> The scores express similarity to known AD genes in this graph. They are hypotheses, not evidence of causality or upstream regulation.

## Repository layout
```
src/common.py                    seeds and hyper-parameters stated in the Methods
src/stage1_preprocessing.py      cohort, QC, KNN imputation, STRING network, differential edges, node features, labels
src/stage2_train.py              GAT, 5-fold CV, baselines, calibration, final model + bootstrap CIs, SHAP
src/stage3_enrichment_figures.py GO enrichment, probability-by-category table, figures
src/stage4_reviewer_analyses.py  leak-free ablation, degree-matched negatives, permutation null, pos:neg ratios, PU learning, tree baselines
src/stage5_external_validation.py cross-cohort validation (e.g. MSBB)
scripts/download_data.py         downloads open resources + Synapse files, writes a provenance manifest
app/streamlit_app.py             interactive explorer of the outputs
data/reference/positive_genes.txt the 57 positive labels (Supplementary Table S1)
docs/DATA.md                     where every dataset comes from + access steps      docs/REVIEWER_MAP.md  comment → code map
```

## Install
```bash
mamba env create -f environment.yml && conda activate gatad      # or: pip install -r requirements.txt (+ torch, torch_geometric)
```

## Run
```bash
python scripts/download_data.py --only string gwas go             # open resources  (controlled Synapse files: docs/DATA.md)
python src/stage1_preprocessing.py --root data --proteomics <matrix> --map-file <tmt_metadata> --network-stats
python src/stage2_train.py         --root data --repeats 10 --ensemble-seeds 20
python src/stage3_enrichment_figures.py --root data --obo data/raw/go-basic.obo --gaf data/raw/goa_human.gaf.gz
python src/stage4_reviewer_analyses.py  --root data --analysis all --repeats 10
python src/stage5_external_validation.py --root data --external-root data_msbb
streamlit run app/streamlit_app.py -- --root data
```
Each script prints the key numbers and writes tables to `data/processed/` and `data/results/`. Run `-h` on any script for options.
Exact betweenness on ~5k nodes / ~45k edges takes minutes; the GPU is optional (the graph is small).

## Modelling choices (see docstrings for details)
* **Graph:** STRING combined score ≥ 700 among quantified proteins; edge kept if `|r_AD| > 0.3` and BH-FDR < 0.05 for the AD-vs-control
  difference (Fisher z). `--edge-rule strengthened|positive` makes the "strengthened in AD" reading explicit.
* **Features:** degree, PageRank (α = 0.85, STRING-weighted), normalised betweenness, clustering coefficient, log2 fold-change (z-scored).
* **Model:** `GATConv(5→64×4 heads)` → LeakyReLU → `GATConv(256→32×4)` → LeakyReLU → `GATConv(128→1)`; attention dropout 0.6, Adam
  (lr 0.005, wd 5e-4), BCE, ≤ 200 epochs; two hidden multi-head layers plus a single-head output layer. Binary graph by default
  (`--edge-attr string|abs_r` feeds scores as edge features).
* **Evaluation:** stratified 5-fold CV over the 257 labelled proteins (60/20/20); baselines degree, PageRank, logistic regression, GCN;
  paired differences use the Nadeau–Bengio corrected resampled t-test, not a signed-rank test on 5 folds.
* **Labels:** positives = Supplementary Table S1; negatives = 200 proteins sampled with `random.seed(2024)` from quantified proteins without
  any reported AD association. The sampled list is written to `processed/negative_genes.txt`; deposit it with the paper (or place a fixed list
  in `data/reference/negative_genes.txt` and stage 1 will use it).

## Reproducibility
Seeds: python 2024, numpy 42, torch 1234 (+ fold offset). GPU message passing is not bit-wise deterministic, so repeat runs differ slightly;
report mean ± SD over `--repeats`. Record versions with `pip freeze`, and keep `data/raw/DATA_MANIFEST.json` (URLs, SHA-256, GO version).
To mint a DOI: connect the GitHub repository to Zenodo, create a release, then add the DOI to `CITATION.cff` and the Data/Code Availability statement.

## Data and licence
ROS/MAP and MSBB are controlled-access: never commit them (`.gitignore` excludes `data/raw`, `data/processed`, `results`). Code is MIT-licensed
(fill in `LICENSE` and `CITATION.cff`).
