"""
GAT-AD explorer — interactive interface to the outputs of the pipeline (stages 1-5).

    streamlit run app/streamlit_app.py -- --root data
    (or set the environment variable GATAD_ROOT)

The app only READS files produced by the pipeline (<root>/processed and <root>/results); it never trains anything.
Scores are similarity to known AD genes in a differential PPI graph. They are hypotheses, not evidence of causality.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import networkx as nx
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

st.set_page_config(page_title="GAT-AD explorer", page_icon="🧠", layout="wide")


def _root() -> str:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=os.environ.get("GATAD_ROOT", "data"))
    return ap.parse_known_args(sys.argv[1:])[0].root


# --------------------------------------------------------------------------- loading
@st.cache_data(show_spinner=False)
def read_csv(path: str, **kw):
    p = Path(path)
    return pd.read_csv(p, **kw) if p.exists() else None


@st.cache_data(show_spinner=False)
def read_json(path: str):
    p = Path(path)
    return json.loads(p.read_text()) if p.exists() else None


def need(df, what: str) -> bool:
    if df is None:
        st.info(f"`{what}` not found — run the corresponding pipeline stage first.")
        return False
    return True


root = st.sidebar.text_input("Results root", _root())
proc, res = Path(root) / "processed", Path(root) / "results"
feat = read_csv(str(proc / "node_features.csv"))
edges = read_csv(str(proc / "edges_differential.csv.gz"))
pred = read_csv(str(res / "predictions_all_nodes.csv"))
rep1 = read_json(str(proc / "stage1_report.json")) or {}
cal = read_json(str(res / "calibration.json"))

st.title("🧠 Graph-attention prioritisation of AD proteins")
st.caption("Differential PPI network from post-mortem DLPFC proteomics → five node features → GAT. "
           "Scores indicate similarity to known AD genes; they are hypotheses, not causal evidence.")
if feat is None:
    st.error(f"No pipeline outputs found under `{root}`. Run `src/stage1_preprocessing.py` and `src/stage2_train.py` first.")
    st.stop()

tabs = st.tabs(["Overview", "Protein explorer", "Candidate ranking", "Model performance", "Interpretation",
                "Robustness (review analyses)", "External validation", "About"])

# --------------------------------------------------------------------------- Overview
with tabs[0]:
    c = st.columns(5)
    c[0].metric("Proteins (nodes)", f"{rep1.get('n_nodes', len(feat)):,}")
    c[1].metric("STRING ≥0.7 edges", f"{rep1.get('n_edges_full', 0):,}")
    c[2].metric("Differential edges", f"{rep1.get('n_edges_diff', len(edges) if edges is not None else 0):,}")
    c[3].metric("Known AD genes (label 1)", int((pred.label == 1).sum()) if pred is not None else "–")
    c[4].metric("Negative controls (label 0)", int((pred.label == 0).sum()) if pred is not None else "–")
    if rep1.get("edge_categories"):
        ec = rep1["edge_categories"]
        st.write(f"**Edge rule:** `{rep1.get('edge_rule', 'abs')}` · AD-exclusive {ec.get('AD_exclusive', 0):,} · "
                 f"strengthened in AD {ec.get('strengthened_in_AD', 0):,} · median |r| AD {rep1.get('median_abs_r_ad', float('nan')):.2f} "
                 f"vs control {rep1.get('median_abs_r_ctrl', float('nan')):.2f}")
    if rep1.get("qc"):
        q = rep1["qc"]
        st.write(f"**QC:** {q['n_proteins_after']:,}/{q['n_proteins_before']:,} proteins kept (≥70 % quantified); minimum observed values per "
                 f"retained protein before imputation = {q['min_observed_per_protein']} of {q['n_samples']} samples.")
    t4 = read_csv(str(res / "table4_gat_cv.csv"), index_col=0)
    if t4 is not None:
        st.subheader("Cross-validated performance of the GAT")
        st.dataframe(t4.round(3), width="stretch")
    for f, cap in (("table2_sample_characteristics.csv", "Cohort characteristics"), ("table3_node_features.csv", "Node features: drivers vs bystanders (Mann–Whitney U)")):
        d = read_csv(str(proc / f))
        if d is not None:
            st.subheader(cap)
            st.dataframe(d, width="stretch", hide_index=True)

# --------------------------------------------------------------------------- Protein explorer
with tabs[1]:
    genes = sorted(feat.gene)
    default = pred.loc[pred.label != 1, "gene"].iloc[0] if pred is not None else genes[0]
    g = st.selectbox("Protein (gene symbol)", genes, index=genes.index(default))
    row = feat[feat.gene == g].iloc[0]
    lab = {1: "known AD gene (positive label)", 0: "negative control", -1: "unlabelled"}
    prow = pred[pred.gene == g].iloc[0] if pred is not None else None
    left, right = st.columns([1, 2])
    with left:
        st.subheader(g)
        if prow is not None:
            st.write(f"**Label:** {lab[int(prow.label)]}")
            nonpos = pred[pred.label != 1].reset_index(drop=True)
            rank = int(nonpos.index[nonpos.gene == g][0]) + 1 if prow.label != 1 else None
            st.metric("Driver probability (ensemble)", f"{prow.prob_ensemble:.3f}",
                      help="Mean of the final models. For labelled genes this is in-sample; use the out-of-fold value.")
            st.write(f"95 % bootstrap CI over models: {prow.ci_low:.3f} – {prow.ci_high:.3f}")
            if prow.label >= 0 and not np.isnan(prow.oof_prob):
                st.write(f"Out-of-fold probability: **{prow.oof_prob:.3f}**")
            if rank:
                st.write(f"Rank among non-positive proteins: **{rank:,}** / {len(nonpos):,}")
        st.dataframe(pd.DataFrame({"raw": row[["degree", "pagerank", "betweenness", "clustering", "fold_change"]],
                                   "z-score": row[[c + "_z" for c in ["degree", "pagerank", "betweenness", "clustering", "fold_change"]]].values}).round(4))
    with right:
        if edges is not None:
            nb = edges[(edges.source == g) | (edges.target == g)].copy()
            nb["partner"] = np.where(nb.source == g, nb.target, nb.source)
            st.write(f"**{len(nb)} differential interaction partners**")
            k = st.slider("Show strongest partners (by |r in AD|)", 5, 80, min(30, max(5, len(nb))))
            nb = nb.reindex(nb.r_ad.abs().sort_values(ascending=False).index).head(k)
            if len(nb):
                G = nx.Graph()
                for _, r in nb.iterrows():
                    G.add_edge(g, r.partner, r_ad=r.r_ad, cat=r.category)
                pos = nx.spring_layout(G, seed=1, k=0.6)
                prob = pred.set_index("gene").prob_ensemble if pred is not None else pd.Series(dtype=float)
                labs = pred.set_index("gene").label if pred is not None else pd.Series(dtype=float)
                fig = go.Figure()
                for u, v, d in G.edges(data=True):
                    fig.add_trace(go.Scatter(x=[pos[u][0], pos[v][0]], y=[pos[u][1], pos[v][1]], mode="lines", hoverinfo="skip",
                                             line=dict(width=1 + 4 * abs(d["r_ad"]), color="#d62728" if d["r_ad"] > 0 else "#1f77b4"),
                                             opacity=0.5, showlegend=False))
                ns = list(G.nodes)
                fig.add_trace(go.Scatter(
                    x=[pos[n][0] for n in ns], y=[pos[n][1] for n in ns], mode="markers+text", text=ns, textposition="top center",
                    marker=dict(size=[26 if n == g else 14 for n in ns], color=[prob.get(n, np.nan) for n in ns], colorscale="Viridis",
                                cmin=0, cmax=1, showscale=True, colorbar=dict(title="P(driver)"),
                                line=dict(width=[3 if labs.get(n, -1) == 1 else 0.5 for n in ns], color="black")),
                    hovertext=[f"{n}<br>P={prob.get(n, float('nan')):.3f}" for n in ns], hoverinfo="text", showlegend=False))
                fig.update_layout(height=520, margin=dict(l=0, r=0, t=10, b=0), xaxis=dict(visible=False), yaxis=dict(visible=False),
                                  plot_bgcolor="white")
                st.plotly_chart(fig, width="stretch")
                st.caption("Edge width ∝ |r in AD|; red = positive, blue = negative correlation in AD. Node colour = predicted probability; "
                           "black outline = known AD gene.")
                st.dataframe(nb[["partner", "r_ad", "r_ctrl", "fdr", "weight", "category"]].round(4), hide_index=True, width="stretch")

# --------------------------------------------------------------------------- Candidate ranking
with tabs[2]:
    if need(pred, "results/predictions_all_nodes.csv"):
        c = st.columns(4)
        pmin = c[0].slider("Minimum probability", 0.0, 1.0, 0.5, 0.01)
        show_known = c[1].checkbox("Include known AD genes", False)
        show_neg = c[2].checkbox("Include negative controls", False)
        dmax = c[3].number_input("Max degree (0 = no limit)", 0, int(pred.degree.max()), 0)
        d = pred.copy()
        if not show_known:
            d = d[d.label != 1]
        if not show_neg:
            d = d[d.label != 0]
        d = d[d.prob_ensemble >= pmin]
        if dmax:
            d = d[d.degree <= dmax]
        d = d.reset_index(drop=True)
        d.insert(0, "rank", d.index + 1)
        st.write(f"{len(d):,} proteins")
        st.dataframe(d.round(4), width="stretch", hide_index=True)
        st.download_button("Download table (CSV)", d.to_csv(index=False), "gatad_candidates.csv")
        fig = px.scatter(pred.assign(group=pred.label.map({1: "known AD", 0: "negative", -1: "unlabelled"})), x="degree", y="prob_ensemble",
                         color="group", log_x=True, hover_name="gene", opacity=0.6,
                         color_discrete_map={"known AD": "#d62728", "negative": "#7f7f7f", "unlabelled": "#aec7e8"},
                         labels={"prob_ensemble": "P(driver)", "degree": "degree in differential network"})
        st.plotly_chart(fig, width="stretch")
        st.caption("Is the score just degree? Compare the spread of probabilities at a given degree; see the degree-matched analysis "
                   "under *Robustness*.")

# --------------------------------------------------------------------------- Model performance
with tabs[3]:
    z = res / "cv_curves.npz"
    if z.exists():
        zz = np.load(z)
        g = zz["grid"]
        c1, c2 = st.columns(2)
        for col, key, xl, yl in ((c1, "roc", "False-positive rate", "True-positive rate"), (c2, "pr", "Recall", "Precision")):
            fig = go.Figure()
            for i, cur in enumerate(zz[key]):
                fig.add_trace(go.Scatter(x=g, y=cur, mode="lines", line=dict(width=1, color="lightgrey"), name=f"fold {i+1}", showlegend=False))
            fig.add_trace(go.Scatter(x=g, y=zz[key].mean(0), mode="lines", line=dict(width=3), name="mean"))
            fig.update_layout(height=380, xaxis_title=xl, yaxis_title=yl, margin=dict(t=10))
            col.plotly_chart(fig, width="stretch")
    if cal:
        c = st.columns(3)
        c[0].metric("Brier score (pooled OOF)", f"{cal['brier']:.3f}")
        c[1].metric("ECE (10 quantile bins)", f"{cal['ece']:.3f}")
        cm = cal["confusion"]
        c[2].write(f"Confusion @0.5 (pooled OOF): TP {cm['TP']}, FN {cm['FN']}, FP {cm['FP']}, TN {cm['TN']}  \n"
                   f"Precision {cm['TP']/max(cm['TP']+cm['FP'],1):.3f}")
        fig = go.Figure([go.Scatter(x=[0, 1], y=[0, 1], mode="lines", line=dict(dash="dash"), name="ideal"),
                         go.Scatter(x=cal["calib_pred"], y=cal["calib_true"], mode="lines+markers", name="GAT")])
        fig.update_layout(height=340, xaxis_title="mean predicted probability", yaxis_title="observed fraction of drivers", margin=dict(t=10))
        st.plotly_chart(fig, width="stretch")
    t5 = read_csv(str(res / "table5_baselines.csv"))
    if t5 is not None:
        st.subheader("Baselines and paired comparison with the GAT")
        st.dataframe(t5, width="stretch", hide_index=True)
        st.caption("Differences are GAT − method over all paired folds; p-values come from the Nadeau–Bengio corrected resampled t-test.")
    cvf = read_csv(str(res / "cv_fold_metrics.csv"))
    if cvf is not None:
        with st.expander("Per-fold metrics"):
            st.dataframe(cvf.round(4), width="stretch", hide_index=True)

# --------------------------------------------------------------------------- Interpretation
with tabs[4]:
    sh = read_csv(str(res / "table8_shap.csv"))
    if sh is not None:
        st.subheader("Feature importance (mean |SHAP|, probability units)")
        fig = px.bar(sh.sort_values("mean_abs_shap"), x="mean_abs_shap", y="feature", orientation="h",
                     error_x=sh.sort_values("mean_abs_shap").ci_high - sh.sort_values("mean_abs_shap").mean_abs_shap,
                     error_x_minus=sh.sort_values("mean_abs_shap").mean_abs_shap - sh.sort_values("mean_abs_shap").ci_low)
        fig.update_layout(height=320, margin=dict(t=10))
        st.plotly_chart(fig, width="stretch")
    go_t = read_csv(str(res / "table9_go_enrichment.csv"))
    if go_t is not None:
        st.subheader("GO enrichment of top-ranked non-positive proteins")
        st.dataframe(go_t.head(30).round(5), width="stretch", hide_index=True)
    t10 = read_csv(str(res / "table10_probability_by_category.csv"))
    if t10 is not None:
        st.subheader("Predicted probability by category")
        st.dataframe(t10.round(3), width="stretch", hide_index=True)
        st.caption("Known genes and negatives use out-of-fold probabilities. High scores of top-ranked candidates are selected "
                   "by score and are not independent validation.")
    if sh is None and go_t is None and t10 is None:
        st.info("Run stage 2 (SHAP) and stage 3 (GO enrichment, category table) to populate this tab.")

# --------------------------------------------------------------------------- Robustness
with tabs[5]:
    rv = res / "reviewer"
    items = [("leakfree_summary.csv", "Leak-free / inductive ablation (topology recomputed without test nodes; scaler fit on training nodes)"),
             ("trees_summary.csv", "Tree-based baselines on the five tabular features"),
             ("degree_matched_summary.csv", "Degree-matched negatives (mean ± SD over replicates)"),
             ("ratios_summary.csv", "Positive:negative ratios"),
             ("pu_summary.csv", "Non-negative PU learning (bystanders not used as negatives)")]
    shown = False
    for f, cap in items:
        d = read_csv(str(rv / f))
        if d is not None:
            shown = True
            st.subheader(cap)
            st.dataframe(d.round(3), width="stretch", hide_index=True)
    pn = read_csv(str(rv / "permutation_null.csv"))
    if pn is not None:
        shown = True
        st.subheader("Label-permutation null")
        s = read_json(str(rv / "reviewer_summary.json")) or {}
        st.plotly_chart(px.histogram(pn, x="AUROC", nbins=20).update_layout(height=300, margin=dict(t=10)), width="stretch")
        if s.get("permutation"):
            st.json(s["permutation"])
    if not shown:
        st.info("Run `src/stage4_reviewer_analyses.py` to populate this tab.")

# --------------------------------------------------------------------------- External validation
with tabs[6]:
    ext = sorted(res.glob("external_*/transfer_summary.json"))
    if not ext:
        st.info("Run `src/stage5_external_validation.py` to populate this tab.")
    for f in ext:
        s = json.loads(f.read_text())
        st.subheader(f"Discovery → {s['external_cohort']}")
        rows = [dict(model=k, n=v["n"], drivers=v["n_pos"], AUROC=v["pooled_AUROC"], AUROC_CI=f"{v['AUROC_CI95'][0]:.3f}–{v['AUROC_CI95'][1]:.3f}",
                     AUPRC=v["pooled_AUPRC"], AUPRC_CI=f"{v['AUPRC_CI95'][0]:.3f}–{v['AUPRC_CI95'][1]:.3f}", prevalence=v["prevalence"])
                for k, v in s.items() if isinstance(v, dict) and "pooled_AUROC" in v]
        st.dataframe(pd.DataFrame(rows).round(3), width="stretch", hide_index=True)
        if "ranking_concordance" in s:
            st.json(s["ranking_concordance"])

# --------------------------------------------------------------------------- About
with tabs[7]:
    st.markdown("""
**What the model does.** A three-layer graph attention network is trained on 5 node features of a disease-enriched PPI graph to separate
known AD genes (GWAS / Alzforum) from randomly sampled bystanders, and is then used to score every protein.

**How to read the scores.** They express similarity to known AD genes in this graph, not causality or upstream regulation. Known-gene
labels are biased towards well-studied, high-degree genes, and unlabelled proteins are treated as negatives during training; see the
robustness tab for degree-matched, PU-learning and leak-free analyses.

**Data.** ROS/MAP (clinical + TMT proteomics, DLPFC; AD Knowledge Portal), STRING v12.0, GWAS Catalog, Gene Ontology. See `docs/DATA.md`.
""")
