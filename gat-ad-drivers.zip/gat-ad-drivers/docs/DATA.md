# Data sources and how to obtain them

All inputs go to `data/raw/` (`python scripts/download_data.py --list` prints this table). Record the versions you used.

| # | Resource | Link | Access | Used for |
|---|---|---|---|---|
| 1 | **ROS/MAP clinical metadata** `ROSMAP_clinical.csv` | https://www.synapse.org/Synapse:syn3191087 | controlled (Synapse login + data-use approval) | cohort selection (`cogdx`, age, sex, PMI, Braak, CERAD) |
| 2 | **ROS/MAP DLPFC TMT proteomics** — log2 abundance matrix (file name encodes 8,817 proteins × 400 samples, median-polish batch-corrected) | https://www.synapse.org/Synapse:syn21266454 | controlled | expression matrix |
| 2b | ROS/MAP study page (all proteomic files, metadata, data-access instructions) | https://adknowledgeportal.synapse.org/Explore/Studies/DetailsPage/StudyDetails?Study=syn3219045 | — | find the **TMT sample-metadata file** that maps matrix columns (`b#.channel`) to `individualID`/`projid`; pass it as `--map-file` |
| 3 | **STRING v12.0, *H. sapiens* (9606)** `9606.protein.links.v12.0.txt.gz`, `9606.protein.info.v12.0.txt.gz` | https://version-12-0.string-db.org/cgi/download (direct: `https://stringdb-downloads.org/download/protein.links.v12.0/…`) | open | PPI edges (combined score ≥ 700), gene symbols |
| 4 | **GWAS Catalog** `gwas-catalog-associations_ontology-annotated.tsv` | https://www.ebi.ac.uk/gwas/docs/file-downloads (FTP: https://ftp.ebi.ac.uk/pub/databases/gwas/releases/latest/) | open | screening negatives against every AD-reported gene |
| 5 | **Gene Ontology** `go-basic.obo` + `goa_human.gaf.gz` | https://geneontology.org/docs/downloads/ (archive: https://release.geneontology.org/) | open | enrichment (stage 3); record `data-version` |
| 6 | **Alzforum Mutations** | https://www.alzforum.org/mutations | open | APP, PSEN1, PSEN2 are hard-coded; nothing to download |
| 7 | **57 positive genes** | `data/reference/positive_genes.txt` (Supplementary Table S1; ships with the repo) | — | positive labels |
| 8 | **External cohort (Reviewer 3)** — Mount Sinai Brain Bank study page | https://adknowledgeportal.synapse.org/Explore/Studies/DetailsPage/StudyDetails?Study=syn3159438 | controlled | stage 5 (MSBB TMT proteomics; locate the abundance matrix + clinical file on the study page) |

## Access steps for the controlled AMP-AD resources
1. Create a Synapse account and follow https://adknowledgeportal.synapse.org/Data%20Access (registration + data-use terms).
2. Create a personal access token (Synapse → Account Settings → Personal Access Tokens; scopes *view* and *download*).
3. `export SYNAPSE_AUTH_TOKEN=…` then `python scripts/download_data.py --only synapse [--synapse-extra synXXXXXXXX …]`.

I could not verify the Synapse ID of the TMT sample-metadata file or of the MSBB abundance matrix; take them from the study pages (2b, 8).

## Things to check on real data
* **Mapping columns to people.** TMT columns are batch/channel identifiers. Stage 1 refuses to guess: give `--map-file` and, if the column
  names differ, `--map-col-sample / --map-col-id / --map-col-batch`. Batch/channel identifiers can be reused across studies, so confirm
  that every retained column resolves to exactly one ROS/MAP `individualID` (stage 1 prints the counts).
* **100 + 100 donors.** Stage 1 needs ≥ 100 AD (`cogdx` 4) and ≥ 100 control (`cogdx` 1) donors with proteomics and complete metadata. If the
  public matrix has fewer, it stops with the counts; relax with `--ad-cogdx 4 5` and state this in the Methods.
* **ComBat.** The public matrix is already batch-corrected, so a second ComBat is normally unnecessary. Stage 1 runs it only if batch
  information is supplied; `--combat no` disables it.
* **External cohort.** Build a table `sample_id,group,batch` (group ∈ AD/Control; use the cohort's own, pre-declared case/control definition)
  and run `stage1_preprocessing.py --root data_msbb --proteomics <matrix> --cohort-table cohort.csv`.

## What may be deposited publicly
Code, the 57-gene list, the sampled negative list (`processed/negative_genes.txt`), gene-level predictions and figures are normally fine.
Do **not** upload ROS/MAP / MSBB individual-level data or the raw matrices. Check the AMP-AD terms before sharing sample-level derived tables
(e.g. `processed/expression.csv.gz`, `samples.csv`). `.gitignore` already excludes `data/raw`, `data/processed` and `results/`.
