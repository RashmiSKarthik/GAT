#!/usr/bin/env bash
# End-to-end run. Edit PROT / MAP after downloading the data (docs/DATA.md).  Usage: bash run_pipeline.sh
set -euo pipefail
ROOT=data
PROT="${PROT:?set PROT to the proteomics matrix file name inside data/raw/}"
MAP="${MAP:?set MAP to the TMT sample-metadata file name inside data/raw/}"

python scripts/download_data.py --root $ROOT --only string gwas go          # open resources (Synapse files: see docs/DATA.md)
python src/stage1_preprocessing.py --root $ROOT --proteomics "$PROT" --map-file "$MAP" --network-stats
python src/stage2_train.py        --root $ROOT --repeats 10 --ensemble-seeds 20
python src/stage3_enrichment_figures.py --root $ROOT --obo $ROOT/raw/go-basic.obo --gaf $ROOT/raw/goa_human.gaf.gz
python src/stage4_reviewer_analyses.py  --root $ROOT --analysis all --repeats 10
# external cohort (after: stage1 --root data_msbb ... --cohort-table cohort.csv ; stage2 --root data_msbb)
# python src/stage5_external_validation.py --root $ROOT --external-root data_msbb
streamlit run app/streamlit_app.py -- --root $ROOT
