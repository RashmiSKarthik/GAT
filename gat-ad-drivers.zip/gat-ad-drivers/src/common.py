"""
common.py — shared constants, seeds and path helpers for the GAT / Alzheimer's driver-protein pipeline.

Every number in the "PAPER" block below is taken verbatim from the manuscript
("Graph Attention Networks Identify Kinase-Chaperone Driver Modules in Alzheimer's
Disease Proteomic Networks", Sections 3.1-3.7).
"""
from __future__ import annotations

import os
import random
from dataclasses import dataclass
from pathlib import Path

import numpy as np

# --------------------------------------------------------------------------- #
# PAPER settings (Sections 3.1 - 3.7)
# --------------------------------------------------------------------------- #
SEED_PYTHON = 2024      # python `random`  (negative-label sampling, Sec 3.3)
SEED_NUMPY = 42         # numpy / sklearn splits
SEED_TORCH = 1234       # PyTorch

N_PER_GROUP = 100               # 100 AD + 100 control (Sec 3.1)
MIN_PRESENT_FRAC = 0.70         # protein must be quantified in >= 70 % of samples
KNN_K = 10                      # KNN imputation, k = 10
STRING_MIN_SCORE = 700          # combined score >= 0.7
R_AD_MIN = 0.30                 # |r_AD| > 0.3
FDR_ALPHA = 0.05                # BH FDR < 0.05 for r_AD - r_ctrl
PAGERANK_ALPHA = 0.85
PAGERANK_TOL = 1e-6
N_NEGATIVES = 200
FEATURES = ["degree", "pagerank", "betweenness", "clustering", "fold_change"]

# GAT (Sec 3.6)
HIDDEN1, HIDDEN2 = 64, 32
HEADS = 4
DROPOUT = 0.6
LEAKY_SLOPE = 0.2
LR = 0.005
WEIGHT_DECAY = 5e-4
EPOCHS = 200
N_FOLDS = 5
N_BOOT = 1000


def set_seeds(python: int = SEED_PYTHON, numpy: int = SEED_NUMPY, torch_seed: int | None = SEED_TORCH) -> None:
    """Seed python / numpy / torch exactly as stated in the paper."""
    random.seed(python)
    np.random.seed(numpy)
    os.environ["PYTHONHASHSEED"] = str(python)
    if torch_seed is not None:
        try:
            import torch
            torch.manual_seed(torch_seed)
            torch.cuda.manual_seed_all(torch_seed)
        except ImportError:  # stage 1 does not need torch
            pass


@dataclass
class Paths:
    root: Path
    raw: Path
    proc: Path
    res: Path

    def mk(self) -> "Paths":
        for p in (self.raw, self.proc, self.res):
            p.mkdir(parents=True, exist_ok=True)
        return self


def get_paths(root: str | os.PathLike = "data") -> Paths:
    r = Path(root)
    return Paths(r, r / "raw", r / "processed", r / "results").mk()
