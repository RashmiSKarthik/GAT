#!/usr/bin/env python
"""
Stage 1 — data preprocessing, differential PPI network, node features and labels
(manuscript Sections 3.1 - 3.5, results 4.1 - 4.3).

Inputs  (put in <root>/raw/; `python scripts/download_data.py` fetches them, see docs/DATA.md)
    ROSMAP_clinical.csv               Synapse syn3191087
    <proteomics matrix>               ROSMAP TMT DLPFC log2 abundance (rows = proteins, cols = samples), Synapse syn21266454
    <sample map>                      matrix column (batch.channel) -> individualID / projid  (required for ROSMAP TMT)
    9606.protein.links.v12.0.txt.gz   STRING v12.0
    9606.protein.info.v12.0.txt.gz    STRING v12.0
    gwas-catalog-associations_ontology-annotated.tsv   GWAS Catalog (used only to build the negative-exclusion set)
    positive_genes.txt                57 positives (Supplementary Table S1; shipped in data/reference/)
    negative_genes.txt (optional)     a fixed list of 200 negatives; otherwise sampled with random.seed(2024)
  External cohorts (e.g. MSBB): use --cohort-table instead of the ROSMAP clinical file.

Outputs (<root>/processed/)
    samples.csv, expression.csv.gz, edges_full.csv.gz, edges_differential.csv.gz,
    node_features.csv, labels.csv, negative_pool.txt, negative_genes.txt, table2_sample_characteristics.csv,
    table3_node_features.csv, stage1_report.json
"""
from __future__ import annotations

import argparse
import json
import random
import re
import warnings
from pathlib import Path

import networkx as nx
import numpy as np
import pandas as pd
from scipy import sparse, stats
from scipy.sparse.csgraph import connected_components, shortest_path
from sklearn.impute import KNNImputer
from statsmodels.stats.multitest import multipletests

import common as C


# =========================================================================== #
# helpers
# =========================================================================== #
def read_table(path: Path, **kw) -> pd.DataFrame:
    """CSV / TSV (optionally .gz) with automatic delimiter detection."""
    return pd.read_csv(path, sep=None, engine="python", **kw)


def feature_to_symbol(fid) -> str:
    """'ACTB|P60709' -> 'ACTB';  'sp|P60709|ACTB_HUMAN' -> 'ACTB';  'ACTB' -> 'ACTB'."""
    fid = str(fid).strip()
    if fid.startswith(("sp|", "tr|")):
        parts = fid.split("|")
        return parts[2].replace("_HUMAN", "") if len(parts) > 2 else parts[1]
    return fid.split("|")[0]


def parse_age(x) -> float:
    """ROSMAP top-codes ages >= 90 as '90+'."""
    if pd.isna(x):
        return np.nan
    return float(str(x).replace("+", ""))


def read_gene_list(path: Path) -> list[str]:
    return [l.strip() for l in Path(path).read_text().splitlines() if l.strip() and not l.startswith("#")]


# =========================================================================== #
# 3.1  cohort selection + proteomic matrix
# =========================================================================== #
def load_clinical(path: Path) -> pd.DataFrame:
    clin = read_table(path)
    need = ["individualID", "projid", "msex", "age_death", "pmi", "braaksc", "ceradsc", "cogdx"]
    miss = [c for c in need if c not in clin.columns]
    if miss:
        raise SystemExit(f"[clinical] missing columns {miss}; found {list(clin.columns)}")
    clin = clin.drop_duplicates("individualID").copy()
    clin["individualID"] = clin["individualID"].astype(str)
    clin["projid_str"] = clin["projid"].astype("Int64").astype(str).str.zfill(8)
    clin["age_death"] = clin["age_death"].map(parse_age)
    return clin


def load_proteomics(path: Path) -> pd.DataFrame:
    raw = read_table(path, index_col=0)
    raw = raw.apply(pd.to_numeric, errors="coerce")
    raw.index = [feature_to_symbol(i) for i in raw.index]
    # duplicated symbols (isoforms): keep the most complete, then most variable row
    raw["_cmp"] = raw.notna().mean(axis=1)
    raw["_var"] = raw.drop(columns="_cmp").var(axis=1)
    raw = raw.sort_values(["_cmp", "_var"], ascending=False)
    raw = raw[~raw.index.duplicated(keep="first")].drop(columns=["_cmp", "_var"])
    return raw


def map_columns_to_individuals(expr: pd.DataFrame, clin: pd.DataFrame, args) -> tuple[pd.DataFrame, pd.Series | None]:
    """Return expression with columns renamed to individualID, plus a batch Series (or None)."""
    batch = None
    cols = pd.Index(expr.columns.astype(str))
    if args.map_file:
        m = read_table(Path(args.map_file))
        for c in (args.map_col_sample, args.map_col_id):
            if c not in m.columns:
                raise SystemExit(f"[map] column '{c}' not in {list(m.columns)} — set --map-col-sample/--map-col-id")
        m[args.map_col_sample] = m[args.map_col_sample].astype(str)
        m = m.drop_duplicates(args.map_col_sample).set_index(args.map_col_sample)
        keep = cols.isin(m.index)
        print(f"[map] {keep.sum()}/{len(cols)} matrix columns found in sample map")
        expr = expr.loc[:, keep]
        cols = pd.Index(expr.columns.astype(str))
        ids = m.loc[cols, args.map_col_id].astype(str).values
        if args.map_col_batch in m.columns:
            batch = pd.Series(m.loc[cols, args.map_col_batch].astype(str).values)
    else:
        if np.mean([bool(re.match(r"^[bB]?\d+\.\d{3}[NC]?$", c)) for c in cols]) > 0.5:
            raise SystemExit("Matrix columns look like TMT batch.channel identifiers: pass --map-file with the Synapse sample "
                             "metadata. Do NOT guess the mapping (batch.channel IDs are reused across studies).")
        ids = cols.values

    id_lookup = {**dict(zip(clin["individualID"], clin["individualID"])),
                 **dict(zip(clin["projid_str"], clin["individualID"]))}
    ind = pd.Series([id_lookup.get(str(i).zfill(8) if str(i).isdigit() else str(i)) for i in ids])
    ok = ind.notna().values
    print(f"[map] {ok.sum()}/{len(ok)} columns resolved to ROSMAP individualID")
    if ok.sum() == 0:
        raise SystemExit("No proteomics column could be matched to ROSMAP_clinical.csv. "
                         "Inspect the TMT sample-metadata file on Synapse and set --map-file/--map-col-*.")
    expr = expr.loc[:, ok]
    expr.columns = ind[ok].values
    if batch is not None:
        batch = pd.Series(batch[ok].values, index=expr.columns)
    dup = expr.columns.duplicated(keep="first")
    if dup.any():
        print(f"[map] dropping {dup.sum()} duplicate columns for the same individual")
        expr = expr.loc[:, ~dup]
        if batch is not None:
            batch = batch[~batch.index.duplicated(keep="first")]
    return expr, batch


def select_cohort(clin: pd.DataFrame, available: set[str], n: int, ad_cogdx, ctrl_cogdx, seed: int) -> pd.DataFrame:
    """100 AD + 100 control with complete metadata, matched on sex (exact) and age at death (nearest)."""
    df = clin[clin["individualID"].isin(available)].copy()
    df["group"] = np.select([df.cogdx.isin(ad_cogdx), df.cogdx.isin(ctrl_cogdx)], ["AD", "Control"], default="")
    df = df[df.group != ""].dropna(subset=["age_death", "msex", "pmi", "braaksc", "ceradsc"])  # criterion (3)
    n_ad, n_ct = (df.group == "AD").sum(), (df.group == "Control").sum()
    print(f"[cohort] eligible with proteomics + complete metadata: AD={n_ad}, Control={n_ct}")
    if min(n_ad, n_ct) < n:
        raise SystemExit(f"Need {n} per group, have AD={n_ad}, Control={n_ct}. Relax criteria (e.g. --ad-cogdx 4 5).")
    rng = np.random.default_rng(seed)
    anchor_g = "AD" if n_ad <= n_ct else "Control"
    other_g = "Control" if anchor_g == "AD" else "AD"
    anchors = df[df.group == anchor_g].sample(n=n, random_state=seed)
    pool = df[df.group == other_g].copy()
    chosen = []
    for _, a in anchors.sample(frac=1, random_state=seed).iterrows():      # random order, greedy NN matching
        cand = pool[(pool.msex == a.msex) & (~pool.individualID.isin(chosen))]
        if cand.empty:
            cand = pool[~pool.individualID.isin(chosen)]
        chosen.append(cand.iloc[(cand.age_death - a.age_death).abs().argmin()].individualID)
    sel = pd.concat([anchors, pool[pool.individualID.isin(chosen)]]).reset_index(drop=True)
    return sel


def table2(sel: pd.DataFrame) -> pd.DataFrame:
    ad, ct = sel[sel.group == "AD"], sel[sel.group == "Control"]
    cerad = lambda d: 4 - d.ceradsc            # ROSMAP codes CERAD 1=definite ... 4=no AD; paper uses 0-3 (higher = worse)
    f = lambda s: f"{s.mean():.1f} ± {s.std():.1f}"
    iqr = lambda s: f"{s.median():.0f} ({s.quantile(.25):.0f}-{s.quantile(.75):.0f})"
    chi = stats.chi2_contingency(pd.crosstab(sel.group, sel.msex == 0))[1]
    rows = [
        ("Age at death (years), mean ± SD", f(ad.age_death), f(ct.age_death), stats.ttest_ind(ad.age_death, ct.age_death)[1]),
        ("Female, n (%)", f"{(ad.msex==0).sum()} ({(ad.msex==0).mean()*100:.0f}%)", f"{(ct.msex==0).sum()} ({(ct.msex==0).mean()*100:.0f}%)", chi),
        ("Post-mortem interval (h), mean ± SD", f(ad.pmi), f(ct.pmi), stats.ttest_ind(ad.pmi, ct.pmi, nan_policy="omit")[1]),
        ("Braak stage, median (IQR)", iqr(ad.braaksc), iqr(ct.braaksc), stats.mannwhitneyu(ad.braaksc, ct.braaksc)[1]),
        ("CERAD score (0-3), median (IQR)", iqr(cerad(ad)), iqr(cerad(ct)), stats.mannwhitneyu(cerad(ad), cerad(ct))[1]),
    ]
    return pd.DataFrame(rows, columns=["Characteristic", "AD (n=%d)" % len(ad), "Control (n=%d)" % len(ct), "p-value"])


def filter_impute(expr: pd.DataFrame, min_frac: float, k: int) -> tuple[pd.DataFrame, dict]:
    n_all = expr.shape[0]
    keep = expr.notna().mean(axis=1) >= min_frac
    expr = expr.loc[keep]
    obs = expr.notna().sum(axis=1)
    qc = dict(n_proteins_before=int(n_all), n_proteins_after=int(keep.sum()), min_observed_per_protein=int(obs.min()),
              median_observed_per_protein=float(obs.median()), n_samples=int(expr.shape[1]))
    print(f"[qc] observed values per retained protein before imputation: min={obs.min()}, median={obs.median():.0f} "
          f"of {expr.shape[1]} samples")
    print(f"[qc] proteins quantified in >= {min_frac:.0%} of {expr.shape[1]} samples: {keep.sum()} / {n_all}"
          f"   (paper: 5,234)")
    miss = expr.isna().mean().mean()
    print(f"[qc] mean missingness after filtering: {miss:.2%}")
    if miss > 0:
        # samples are rows, proteins are features: each missing value is borrowed from the k most similar samples
        imp = KNNImputer(n_neighbors=k, weights="uniform")
        arr = imp.fit_transform(expr.T.values)
        expr = pd.DataFrame(arr.T, index=expr.index, columns=expr.columns)
    return expr, qc


def batch_r2(expr: pd.DataFrame, batch: pd.Series) -> tuple[float, float]:
    """R² and ANOVA p-value of PC1 against batch (paper: R² 0.41 -> 0.03)."""
    x = expr.T.values - expr.T.values.mean(0)
    pc1 = np.linalg.svd(x, full_matrices=False)[0][:, 0]
    groups = [pc1[(batch.values == b)] for b in pd.unique(batch) if (batch.values == b).sum() > 0]
    f, p = stats.f_oneway(*groups)
    ss_b = sum(len(g) * (g.mean() - pc1.mean()) ** 2 for g in groups)
    return ss_b / ((pc1 - pc1.mean()) ** 2).sum(), p


def run_combat(expr: pd.DataFrame, batch: pd.Series, diagnosis: pd.Series) -> pd.DataFrame:
    """Empirical-Bayes ComBat (Python port `inmoose`), diagnosis protected as a covariate."""
    from inmoose.pycombat import pycombat_norm
    batch = batch.reindex(expr.columns)
    sizes = batch.value_counts()
    singles = sizes[sizes < 2].index
    if len(singles):
        batch = batch.where(~batch.isin(singles), "pooled_singletons")
        if (batch == "pooled_singletons").sum() < 2:          # a lone singleton cannot form its own batch -> join the smallest real batch
            smallest = batch[batch != "pooled_singletons"].value_counts().idxmin()
            batch = batch.where(batch != "pooled_singletons", smallest)
        warnings.warn(f"{len(singles)} single-sample batch(es) were pooled before ComBat")
    r2_b, p_b = batch_r2(expr, batch)
    mod = pd.get_dummies(diagnosis.reindex(expr.columns), drop_first=True).astype(float).values
    out = pycombat_norm(expr.values, batch.values, covar_mod=mod)
    out = pd.DataFrame(out, index=expr.index, columns=expr.columns)
    r2_a, p_a = batch_r2(out, batch)
    print(f"[combat] PC1~batch  before: R²={r2_b:.2f} (p={p_b:.2g});  after: R²={r2_a:.2f} (p={p_a:.2g})   (paper: 0.41 -> 0.03)")
    return out


# =========================================================================== #
# 3.2  STRING
# =========================================================================== #
def load_string(links: Path, info: Path, genes: set[str], min_score: int) -> pd.DataFrame:
    inf = pd.read_csv(info, sep="\t")
    inf.columns = [c.lstrip("#") for c in inf.columns]
    id2sym = dict(zip(inf["string_protein_id"], inf["preferred_name"]))
    lk = pd.read_csv(links, sep=" ")
    lk = lk[lk.combined_score >= min_score].copy()
    lk["a"] = lk.protein1.map(id2sym)
    lk["b"] = lk.protein2.map(id2sym)
    lk = lk.dropna(subset=["a", "b"])
    lk = lk[lk.a.isin(genes) & lk.b.isin(genes) & (lk.a != lk.b)]                 # no self-interactions
    lk["u"] = np.where(lk.a < lk.b, lk.a, lk.b)
    lk["v"] = np.where(lk.a < lk.b, lk.b, lk.a)
    lk = lk.groupby(["u", "v"], as_index=False).combined_score.max()              # no duplicate edges
    lk["weight"] = lk.combined_score / 1000.0                                      # [0, 1]
    return lk.rename(columns={"u": "source", "v": "target"})[["source", "target", "weight"]]


# =========================================================================== #
# 3.4  differential network
# =========================================================================== #
def differential_edges(expr: pd.DataFrame, groups: pd.Series, edges: pd.DataFrame,
                       r_min: float, alpha: float, rule: str = "abs") -> pd.DataFrame:
    """Edge-selection rule (applied to STRING >= 0.7 edges; BH-FDR over ALL tested edges):
         abs          |r_AD| > r_min  and  FDR(r_AD vs r_ctrl) < alpha              (the manuscript's literal rule; negative
                      correlations qualify, and a *weaker* correlation in AD can qualify)
         strengthened |r_AD| > r_min, FDR < alpha, and |r_AD| > |r_ctrl|            (correlation strength increased in AD)
         positive     r_AD > r_min,  FDR < alpha, and r_AD > r_ctrl                 (positive correlations only, increased in AD)
    """
    ad = expr.loc[:, groups.reindex(expr.columns) == "AD"].values
    ct = expr.loc[:, groups.reindex(expr.columns) == "Control"].values
    n_ad, n_ct = ad.shape[1], ct.shape[1]
    idx = {g: i for i, g in enumerate(expr.index)}
    ia = edges.source.map(idx).values
    ib = edges.target.map(idx).values

    def pearson(m):
        z = (m - m.mean(1, keepdims=True)) / m.std(1, ddof=1, keepdims=True)
        return np.einsum("ij,ij->i", z[ia], z[ib]) / (m.shape[1] - 1)

    e = edges.copy()
    e["r_ad"], e["r_ctrl"] = pearson(ad), pearson(ct)
    r_ad = e.r_ad.clip(-0.999999, 0.999999)
    r_ct = e.r_ctrl.clip(-0.999999, 0.999999)
    z_ad, z_ct = np.arctanh(r_ad), np.arctanh(r_ct)                              # eq (1)
    se = np.sqrt(1.0 / (n_ad - 3) + 1.0 / (n_ct - 3))                            # eq (2)
    e["z_stat"] = (z_ad - z_ct) / se
    e["p_diff"] = 2 * stats.norm.sf(np.abs(e.z_stat))
    e["fdr"] = multipletests(e.p_diff, method="fdr_bh")[1]                       # Benjamini-Hochberg over ALL edges
    keep = (e.r_ad.abs() > r_min) & (e.fdr < alpha)
    if rule == "strengthened":
        keep &= e.r_ad.abs() > e.r_ctrl.abs()
    elif rule == "positive":
        keep = (e.r_ad > r_min) & (e.fdr < alpha) & (e.r_ad > e.r_ctrl)
    e["enriched"] = keep
    e["category"] = np.where(~keep, "not_enriched",
                             np.where(e.r_ctrl.abs() <= r_min, "AD_exclusive", "strengthened_in_AD"))
    return e


# =========================================================================== #
# 3.5  node features
# =========================================================================== #
def topology_features(nodes: list[str], edges: pd.DataFrame, pagerank_weighted: bool = True,
                      betw_k: int | None = None, verbose: bool = True) -> pd.DataFrame:
    """degree, PageRank (alpha .85, tol 1e-6), normalised betweenness, clustering coefficient of the graph (nodes, edges).
    Nodes without edges are kept (degree 0). Reused by stage4 to recompute features on masked graphs."""
    G = nx.Graph()
    G.add_nodes_from(nodes)
    G.add_weighted_edges_from(edges[["source", "target", "weight"]].itertuples(index=False))
    if verbose:
        print(f"[features] graph: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
    deg = dict(G.degree())                                                       # count of neighbours
    pr = nx.pagerank(G, alpha=C.PAGERANK_ALPHA, tol=C.PAGERANK_TOL, max_iter=1000,
                     weight="weight" if pagerank_weighted else None)
    if verbose:
        print("[features] betweenness (exact is O(VE); minutes for ~5k nodes / ~45k edges) ...")
    bt = nx.betweenness_centrality(G, k=betw_k, normalized=True, seed=C.SEED_NUMPY)
    cc = nx.clustering(G)                                                        # eq (4)
    return pd.DataFrame({"gene": nodes, "degree": [deg[n] for n in nodes], "pagerank": [pr[n] for n in nodes],
                         "betweenness": [bt[n] for n in nodes], "clustering": [cc[n] for n in nodes]})


def node_features(nodes: list[str], diff: pd.DataFrame, expr: pd.DataFrame, groups: pd.Series,
                  pagerank_weighted: bool, betw_k: int | None) -> pd.DataFrame:
    df = topology_features(nodes, diff, pagerank_weighted, betw_k)
    m_ad = expr.loc[nodes, groups.reindex(expr.columns) == "AD"].mean(axis=1)
    m_ct = expr.loc[nodes, groups.reindex(expr.columns) == "Control"].mean(axis=1)
    df["fold_change"] = (m_ad - m_ct).loc[nodes].values                          # eq (5)
    for f in C.FEATURES:                                                         # z-score (mean 0, sd 1)
        df[f + "_z"] = (df[f] - df[f].mean()) / df[f].std(ddof=0)
    return df


def power_law_gamma(deg: np.ndarray) -> float:
    """Discrete power-law exponent by MLE (Clauset et al. 2009), k_min chosen by minimum KS distance."""
    deg = deg[deg > 0]
    best = (np.inf, np.nan)
    for kmin in np.unique(deg)[:-5][:30]:
        x = deg[deg >= kmin]
        if len(x) < 50:
            continue
        g = 1 + len(x) / np.sum(np.log(x / (kmin - 0.5)))
        xs = np.sort(x)
        cdf_emp = np.arange(1, len(xs) + 1) / len(xs)
        ks_vals = np.arange(kmin, xs.max() + 1)
        pmf = ks_vals ** (-g); pmf /= pmf.sum()
        cdf_th = np.cumsum(pmf)[np.searchsorted(ks_vals, xs)]
        ks = np.max(np.abs(cdf_emp - cdf_th))
        if ks < best[0]:
            best = (ks, g)
    return best[1]


def path_stats(nodes: list[str], edges: pd.DataFrame) -> dict:
    idx = {g: i for i, g in enumerate(nodes)}
    n = len(nodes)
    a = sparse.coo_matrix((np.ones(len(edges)), (edges.source.map(idx), edges.target.map(idx))), shape=(n, n))
    a = ((a + a.T) > 0).astype(float).tocsr()
    nc, lab = connected_components(a, directed=False)
    lcc = np.where(lab == np.bincount(lab).argmax())[0]
    d = shortest_path(a[lcc][:, lcc], method="D", unweighted=True, directed=False)
    return {"lcc_nodes": int(len(lcc)), "n_components": int(nc),
            "diameter": int(d.max()), "avg_shortest_path": float(d[np.triu_indices(len(lcc), 1)].mean())}


# =========================================================================== #
# 3.3  labels
# =========================================================================== #
ALZFORUM_GENES = ["APP", "PSEN1", "PSEN2"]    # the Alzforum Mutations database covers exactly these three genes (paper, Sec 3.3)


def parse_gwas_genes(cell, include_intergenic: bool, intergenic_flag) -> list[str]:
    if pd.isna(cell):
        return []
    if (not include_intergenic) and str(intergenic_flag) in ("1", "1.0", "True"):
        return []
    return [g.strip() for g in re.split(r"\s*[,;]\s*|\s+-\s+|\s+x\s+", str(cell)) if g.strip() and g.strip() != "NR"]


def gwas_ad_genes(path: Path, p_thresh: float, include_intergenic: bool) -> tuple[set[str], set[str]]:
    """(genome-wide-significant AD genes, ALL genes ever reported for an AD trait at any p)."""
    want = {"DISEASE/TRAIT", "MAPPED_TRAIT", "MAPPED_GENE", "REPORTED GENE(S)", "P-VALUE", "INTERGENIC"}
    g = pd.read_csv(path, sep="\t", low_memory=False, usecols=lambda c: c in want)   # works for .tsv and single-file .zip
    trait = (g["DISEASE/TRAIT"].fillna("") + " " + g.get("MAPPED_TRAIT", pd.Series("", index=g.index)).fillna("")).str.lower()
    g = g[trait.str.contains("alzheimer")].copy()
    g["p"] = pd.to_numeric(g["P-VALUE"], errors="coerce")
    flag = g["INTERGENIC"] if "INTERGENIC" in g.columns else pd.Series(0, index=g.index)
    sig, anyp = set(), set()
    for gene_cell, rep_cell, pv, fl in zip(g["MAPPED_GENE"], g["REPORTED GENE(S)"], g["p"], flag):
        gs_map = parse_gwas_genes(gene_cell, include_intergenic, fl)
        gs_all = set(parse_gwas_genes(gene_cell, True, 0)) | set(parse_gwas_genes(rep_cell, True, 0))
        anyp |= gs_all
        if pv < p_thresh:
            sig |= set(gs_map)
    print(f"[labels] GWAS Catalog AD rows: {len(g)}; genome-wide-significant genes: {len(sig)}; any-p genes: {len(anyp)}")
    return sig, anyp


def _find(raw: Path, pattern: str):
    hits = sorted(raw.glob(pattern))
    return hits[0] if hits else None


def build_labels(nodes: list[str], args, paths) -> tuple[pd.DataFrame, list[str]]:
    nodeset = set(nodes)
    anyp: set[str] = set()
    ref = Path(__file__).resolve().parent.parent / "data" / "reference"
    pos_file = Path(args.positives) if args.positives else next(
        (p for p in (paths.raw / "positive_genes.txt", ref / "positive_genes.txt") if p.exists()), paths.raw / "positive_genes.txt")
    if pos_file.exists():
        pos = set(read_gene_list(pos_file))
        print(f"[labels] positives read from {pos_file} ({len(pos)} symbols)")
        gwas = Path(args.gwas) if args.gwas else _find(paths.raw, "gwas*catalog*")
        if gwas is not None:
            _, anyp = gwas_ad_genes(gwas, 5e-8, args.gwas_intergenic)
        else:
            print("[labels] WARNING: no GWAS Catalog file found -> negatives are NOT screened against GWAS-reported AD genes")
    else:
        gwas = Path(args.gwas) if args.gwas else _find(paths.raw, "gwas*catalog*")
        if gwas is None:
            raise SystemExit("Provide positive_genes.txt or a GWAS Catalog associations file in raw/.")
        sig, anyp = gwas_ad_genes(gwas, 5e-8, args.gwas_intergenic)
        pos = sig | set(ALZFORUM_GENES)
        print("[labels] WARNING: positives rebuilt from GWAS Catalog + APP/PSEN1/PSEN2. The manuscript's exact 57 genes "
              "(Supplementary Table S1) are not in the paper text — pass them via positive_genes.txt to reproduce.")
    missing = sorted(pos - nodeset)
    pos_in = sorted(pos & nodeset)
    print(f"[labels] positives present in network: {len(pos_in)} / {len(pos)}  (paper: 57)   not in network: {missing[:15]}{'...' if len(missing)>15 else ''}")

    excl = set(pos) | set(ALZFORUM_GENES) | anyp
    extra = paths.raw / "ad_exclusions.txt"
    if extra.exists():
        excl |= set(read_gene_list(extra))
    cand = sorted(nodeset - excl)                       # eligible bystanders: quantified, in STRING, no reported AD association
    neg_file = Path(args.negatives) if args.negatives else next(
        (p for p in (paths.raw / "negative_genes.txt", ref / "negative_genes.txt") if p.exists()), paths.raw / "negative_genes.txt")
    if neg_file.exists():
        neg = sorted(set(read_gene_list(neg_file)) & nodeset)
        print(f"[labels] negatives read from {neg_file}: {len(neg)}")
    else:
        random.seed(C.SEED_PYTHON)                                              # python `random`, seed 2024, no replacement
        neg = sorted(random.sample(cand, min(C.N_NEGATIVES, len(cand))))
        print(f"[labels] negatives: random.sample(seed={C.SEED_PYTHON}) of {len(cand)} candidates -> {len(neg)}")
    lab = pd.DataFrame({"gene": nodes, "label": -1})
    lab.loc[lab.gene.isin(pos_in), "label"] = 1
    lab.loc[lab.gene.isin(neg), "label"] = 0
    return lab, cand


# =========================================================================== #
# descriptive tables
# =========================================================================== #
def table3(feat: pd.DataFrame, lab: pd.DataFrame) -> pd.DataFrame:
    m = feat.merge(lab, on="gene")
    pos, neg = m[m.label == 1], m[m.label == 0]
    rows = []
    for f in C.FEATURES:
        # NB: positives (n=57) and negatives (n=200) are independent samples, so the correct test is the Wilcoxon
        # rank-sum (= Mann-Whitney U). The signed-rank test named in the paper needs paired observations.
        p = stats.mannwhitneyu(pos[f], neg[f])[1] if len(pos) and len(neg) else np.nan
        sd_pooled = np.sqrt((pos[f].var() + neg[f].var()) / 2) if len(pos) and len(neg) else np.nan
        rows.append((f, f"{feat[f].mean():.4g} ± {feat[f].std():.4g}", f"{pos[f].mean():.4g} ± {pos[f].std():.4g}",
                     f"{neg[f].mean():.4g} ± {neg[f].std():.4g}", p, (pos[f].mean() - neg[f].mean()) / sd_pooled))
    return pd.DataFrame(rows, columns=["feature", "all_nodes", "positives", "negatives", "p_mannwhitney", "cohens_d"])


# =========================================================================== #
# main
# =========================================================================== #
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root", default="data")
    ap.add_argument("--clinical", default="ROSMAP_clinical.csv")
    ap.add_argument("--cohort-table", default=None,
                    help="CSV with columns sample_id, group (AD/Control) [, batch]: use instead of the ROSMAP clinical file "
                         "(for external cohorts such as MSBB). Matrix columns must equal sample_id.")
    ap.add_argument("--proteomics", required=True, help="file name inside raw/ (log2 abundance, proteins x samples)")
    ap.add_argument("--map-file", default=None, help="matrix column -> individualID table (raw/ path or absolute)")
    ap.add_argument("--map-col-sample", default="SampleID")
    ap.add_argument("--map-col-id", default="individualID")
    ap.add_argument("--map-col-batch", default="Batch")
    ap.add_argument("--ad-cogdx", type=int, nargs="+", default=[4])
    ap.add_argument("--ctrl-cogdx", type=int, nargs="+", default=[1])
    ap.add_argument("--n-per-group", type=int, default=C.N_PER_GROUP)
    ap.add_argument("--combat", choices=["auto", "yes", "no"], default="auto",
                    help="auto = run only if a batch column is available. NOTE: the public Synapse TMT matrix is already "
                         "TAMPOR/median-polish batch-corrected; a second ComBat is usually redundant (see README).")
    ap.add_argument("--string-links", default="9606.protein.links.v12.0.txt.gz")
    ap.add_argument("--string-info", default="9606.protein.info.v12.0.txt.gz")
    ap.add_argument("--gwas", default=None)
    ap.add_argument("--gwas-intergenic", action="store_true", help="also use intergenic GWAS mappings for positives")
    ap.add_argument("--positives", default=None)
    ap.add_argument("--negatives", default=None)
    ap.add_argument("--edge-rule", choices=["abs", "strengthened", "positive"], default="abs",
                    help="differential-edge rule, see differential_edges() docstring")
    ap.add_argument("--pagerank-unweighted", action="store_true")
    ap.add_argument("--betweenness-k", type=int, default=None, help="sample k pivots (fast, approximate); default exact")
    ap.add_argument("--network-stats", action="store_true", help="power-law exponent, diameter, avg path length")
    args = ap.parse_args()

    paths = C.get_paths(args.root)
    C.set_seeds(torch_seed=None)
    R = paths.raw
    rpt: dict = {}

    # ---- 3.1 cohort & proteomics -------------------------------------------------------------------------------
    expr_raw = load_proteomics(R / args.proteomics)
    print(f"[data] proteomics matrix: {expr_raw.shape[0]} proteins x {expr_raw.shape[1]} columns")
    batch = None
    if args.cohort_table:
        ct = read_table(Path(args.cohort_table) if Path(args.cohort_table).exists() else R / args.cohort_table)
        for c in ("sample_id", "group"):
            if c not in ct.columns:
                raise SystemExit(f"--cohort-table needs columns sample_id, group (found {list(ct.columns)})")
        ct["sample_id"] = ct["sample_id"].astype(str)
        expr_raw.columns = expr_raw.columns.astype(str)
        ct = ct[ct.sample_id.isin(expr_raw.columns) & ct.group.isin(["AD", "Control"])].drop_duplicates("sample_id")
        print(f"[cohort] external cohort table: AD={int((ct.group == 'AD').sum())}, Control={int((ct.group == 'Control').sum())}")
        sel = ct.rename(columns={"sample_id": "individualID"}).reset_index(drop=True)
        sel.to_csv(paths.proc / "samples.csv", index=False)
        groups = sel.set_index("individualID")["group"]
        expr = expr_raw.loc[:, groups.index.astype(str)]
        expr.columns = groups.index
        if "batch" in sel.columns:
            batch = sel.set_index("individualID")["batch"].astype(str)
    else:
        clin = load_clinical(R / args.clinical)
        if args.map_file and not Path(args.map_file).is_absolute() and (R / args.map_file).exists():
            args.map_file = str(R / args.map_file)
        expr_raw, batch = map_columns_to_individuals(expr_raw, clin, args)
        sel = select_cohort(clin, set(expr_raw.columns), args.n_per_group, args.ad_cogdx, args.ctrl_cogdx, C.SEED_NUMPY)
        sel.to_csv(paths.proc / "samples.csv", index=False)
        t2 = table2(sel)
        t2.to_csv(paths.proc / "table2_sample_characteristics.csv", index=False)
        print(t2.to_string(index=False))
        groups = sel.set_index("individualID")["group"]
        expr = expr_raw.loc[:, groups.index]
        if batch is not None:
            batch = batch.reindex(groups.index)

    expr, qc = filter_impute(expr, C.MIN_PRESENT_FRAC, C.KNN_K)
    rpt["qc"] = qc
    rpt["n_proteins_after_qc"] = int(expr.shape[0])

    do_combat = args.combat == "yes" or (args.combat == "auto" and batch is not None)
    if do_combat:
        if batch is None:
            raise SystemExit("--combat yes needs a batch column (--map-file with --map-col-batch).")
        expr = run_combat(expr, batch, groups)
    else:
        print("[combat] skipped (no batch information or --combat no)")

    # ---- 3.2 STRING ---------------------------------------------------------------------------------------------
    edges = load_string(R / args.string_links, R / args.string_info, set(expr.index), C.STRING_MIN_SCORE)
    nodes = sorted(set(edges.source) | set(edges.target))
    expr = expr.loc[nodes]
    print(f"[string] network: {len(nodes)} nodes, {len(edges)} edges   (paper: 5,234 / 72,418)")
    rpt.update(n_nodes=len(nodes), n_edges_full=len(edges))

    # ---- 3.4 differential network ---------------------------------------------------------------------------
    de = differential_edges(expr, groups, edges, C.R_AD_MIN, C.FDR_ALPHA, args.edge_rule)
    rpt["edge_rule"] = args.edge_rule
    diff = de[de.enriched].copy()
    vc = diff.category.value_counts()
    print(f"[diff] enriched edges: {len(diff)} ({len(diff)/len(edges):.1%} of full)   (paper: 45,678 = 63.1%)")
    print(f"[diff] AD_exclusive={vc.get('AD_exclusive',0)}  strengthened={vc.get('strengthened_in_AD',0)}"
          f"   (paper: 18,234 / 27,444)")
    print(f"[diff] median |r_AD|={de.r_ad.abs().median():.2f}  median |r_ctrl|={de.r_ctrl.abs().median():.2f}   (paper: 0.34 / 0.19)")
    rpt.update(n_edges_diff=len(diff), edge_categories=vc.to_dict(),
               median_abs_r_ad=float(de.r_ad.abs().median()), median_abs_r_ctrl=float(de.r_ctrl.abs().median()))
    de.to_csv(paths.proc / "edges_full.csv.gz", index=False)
    diff.to_csv(paths.proc / "edges_differential.csv.gz", index=False)
    expr.to_csv(paths.proc / "expression.csv.gz")

    # ---- 3.5 node features ---------------------------------------------------------------------------------------
    feat = node_features(nodes, diff, expr, groups, not args.pagerank_unweighted, args.betweenness_k)
    feat.to_csv(paths.proc / "node_features.csv", index=False)
    print(feat[C.FEATURES].describe().loc[["mean", "std"]].round(4).to_string())
    print(f"[features] mean PageRank must equal 1/N = {1/len(nodes):.2e}; observed {feat.pagerank.mean():.2e}")

    # ---- 3.3 labels ----------------------------------------------------------------------------------------------
    lab, pool = build_labels(nodes, args, paths)
    lab.to_csv(paths.proc / "labels.csv", index=False)
    (paths.proc / "negative_pool.txt").write_text("\n".join(pool) + "\n")                      # eligible bystanders (stage 4)
    (paths.proc / "negative_genes.txt").write_text("\n".join(lab.gene[lab.label == 0]) + "\n")  # deposit this list with the paper
    rpt.update(n_pos=int((lab.label == 1).sum()), n_neg=int((lab.label == 0).sum()))
    t3 = table3(feat, lab)
    t3.to_csv(paths.proc / "table3_node_features.csv", index=False)
    print(t3.round(4).to_string(index=False))

    if args.network_stats:
        dd_full = pd.Series(np.concatenate([edges.source, edges.target])).value_counts().reindex(nodes).fillna(0).values
        rpt["gamma_full"] = power_law_gamma(dd_full)
        rpt["gamma_diff"] = power_law_gamma(feat.degree.values.astype(float))
        rpt["paths_full"] = path_stats(nodes, edges)
        rpt["paths_diff"] = path_stats(nodes, diff)
        print("[network]", json.dumps({k: rpt[k] for k in ('gamma_full', 'gamma_diff', 'paths_full', 'paths_diff')}, indent=1))

    (paths.proc / "stage1_report.json").write_text(json.dumps(rpt, indent=2, default=str))
    print(f"\nStage 1 finished -> {paths.proc}")


if __name__ == "__main__":
    main()
