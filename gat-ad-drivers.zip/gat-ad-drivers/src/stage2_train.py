#!/usr/bin/env python
"""
Stage 2 — GAT training, 5-fold stratified CV, baselines, calibration, final model, bootstrap CIs, SHAP
(manuscript Sections 3.6 - 3.7, results 4.4 - 4.6).

Protocol implemented exactly as written in the paper
  * node features  : degree, PageRank, betweenness, clustering, fold-change (z-scored)           [Sec 3.5]
  * graph          : disease-enriched differential PPI network (undirected, self-loops added)    [Sec 3.4]
  * model          : GATConv(5->64, 4 heads, concat) -> LeakyReLU -> GATConv(256->32, 4 heads, concat) -> LeakyReLU
                     -> GATConv(128->1, 1 head) -> sigmoid ;  attention dropout 0.6               [Sec 3.6]
  * optimisation   : Adam, lr 0.005, weight decay 5e-4, BCE loss, 200 epochs                       [Sec 3.6]
  * evaluation     : 5-fold stratified CV; in every fold the 80 % train+val part is split 75/25 into
                     train (60 %) / validation (20 %, early stopping); 20 % test                  [Sec 3.7]
  * metrics        : AUROC, AUPRC, accuracy, sensitivity, specificity, precision, F1 (threshold 0.5)
  * baselines      : degree only, PageRank only, logistic regression, GCN, random
  * significance   : Nadeau-Bengio corrected resampled t-test + 95 % CI on paired fold differences (not a signed-rank test)
  * final model    : retrained on all 257 labelled nodes, predicts every node
Outputs in <root>/results/.
"""
from __future__ import annotations

import argparse
import copy
import itertools
import json
import time
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy import stats
from sklearn.calibration import calibration_curve
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, average_precision_score, brier_score_loss, f1_score,
                             precision_recall_curve, precision_score, recall_score, roc_auc_score, roc_curve)
from sklearn.model_selection import RepeatedStratifiedKFold, train_test_split
from torch_geometric.data import Data
from torch_geometric.nn import GATConv, GCNConv
from torch_geometric.utils import k_hop_subgraph, to_undirected

import common as C

DEV = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# =========================================================================== #
# data
# =========================================================================== #
def load_graph(proc: Path, edge_attr: str = "none") -> tuple[Data, pd.DataFrame]:
    """edge_attr: none (binary graph) | string (STRING combined score / 1000) | abs_r (|r_AD| of the differential edge)."""
    feat = pd.read_csv(proc / "node_features.csv")
    lab = pd.read_csv(proc / "labels.csv")
    edges = pd.read_csv(proc / "edges_differential.csv.gz")
    assert (feat.gene.values == lab.gene.values).all()
    idx = {g: i for i, g in enumerate(feat.gene)}
    ei = torch.as_tensor(np.vstack([edges.source.map(idx).values, edges.target.map(idx).values]), dtype=torch.long)
    ea = None
    if edge_attr == "none":
        ei = to_undirected(ei, num_nodes=len(feat))
    else:
        w = edges["weight"].values if edge_attr == "string" else edges["r_ad"].abs().values
        ei, ea = to_undirected(ei, torch.as_tensor(w, dtype=torch.float32).unsqueeze(-1), num_nodes=len(feat), reduce="mean")
    x = torch.tensor(feat[[f + "_z" for f in C.FEATURES]].values, dtype=torch.float32)
    y = torch.tensor(lab.label.values, dtype=torch.float32)                      # -1 unlabelled, 0 bystander, 1 driver
    data = Data(x=x, edge_index=ei, edge_attr=ea, y=y).to(DEV)
    info = feat.merge(lab, on="gene")
    return data, info


# =========================================================================== #
# models
# =========================================================================== #
class GAT(nn.Module):
    """Two hidden multi-head GAT layers + a single-head output layer (paper Sec 3.6)."""

    def __init__(self, in_dim=5, h1=C.HIDDEN1, h2=C.HIDDEN2, heads=C.HEADS, attn_dropout=C.DROPOUT,
                 slope=C.LEAKY_SLOPE, feat_dropout=0.0, edge_dim=None):
        super().__init__()
        self.slope, self.feat_dropout = slope, feat_dropout
        # add_self_loops=True (default): N(i) includes i itself, as in Eq. (7)
        self.c1 = GATConv(in_dim, h1, heads=heads, concat=True, dropout=attn_dropout, negative_slope=slope, edge_dim=edge_dim)
        self.c2 = GATConv(h1 * heads, h2, heads=heads, concat=True, dropout=attn_dropout, negative_slope=slope, edge_dim=edge_dim)
        # output: 1 head -> averaging over heads is the identity; the sigmoid is applied inside the BCE-with-logits loss
        self.c3 = GATConv(h2 * heads, 1, heads=1, concat=False, dropout=attn_dropout, negative_slope=slope, edge_dim=edge_dim)

    def forward(self, x, ei, ea=None):
        x = F.dropout(x, self.feat_dropout, self.training)
        x = F.leaky_relu(self.c1(x, ei, ea), self.slope)
        x = F.dropout(x, self.feat_dropout, self.training)
        x = F.leaky_relu(self.c2(x, ei, ea), self.slope)
        return self.c3(x, ei, ea).squeeze(-1)                                    # logits


class GCN(nn.Module):
    """'Same architecture, no attention' baseline: 64 -> 32 -> 1, LeakyReLU, dropout 0.6 on node embeddings."""

    def __init__(self, in_dim=5, h1=C.HIDDEN1, h2=C.HIDDEN2, dropout=C.DROPOUT, slope=C.LEAKY_SLOPE):
        super().__init__()
        self.c1, self.c2, self.c3 = GCNConv(in_dim, h1), GCNConv(h1, h2), GCNConv(h2, 1)
        self.p, self.slope = dropout, slope

    def forward(self, x, ei, ea=None):
        w = None if ea is None else ea.reshape(-1)
        x = F.leaky_relu(self.c1(x, ei, w), self.slope)
        x = F.dropout(x, self.p, self.training)
        x = F.leaky_relu(self.c2(x, ei, w), self.slope)
        x = F.dropout(x, self.p, self.training)
        return self.c3(x, ei, w).squeeze(-1)


# =========================================================================== #
# training / metrics
# =========================================================================== #
def _auc(y, p):
    return roc_auc_score(y, p) if len(np.unique(y)) == 2 else np.nan


def train_model(model, data, tr, va=None, epochs=C.EPOCHS, lr=C.LR, wd=C.WEIGHT_DECAY, patience=50,
                monitor="auroc", fixed_epochs=False):
    """Full-batch transductive training. Loss only on `tr` nodes. Early stopping on `va` (restores best weights)."""
    model = model.to(DEV)
    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=wd)
    y = data.y
    tr_t = torch.as_tensor(tr, device=DEV)
    va_t = torch.as_tensor(va, device=DEV) if va is not None else None
    best = dict(score=-np.inf, state=None, epoch=epochs, val_auc=np.nan)
    bad = 0
    for ep in range(1, epochs + 1):
        model.train()
        opt.zero_grad()
        out = model(data.x, data.edge_index, data.edge_attr)
        loss = F.binary_cross_entropy_with_logits(out[tr_t], y[tr_t])           # Eq. (10)
        loss.backward()
        opt.step()
        if va_t is None or fixed_epochs:
            continue
        model.eval()
        with torch.no_grad():
            out = model(data.x, data.edge_index, data.edge_attr)
            vloss = F.binary_cross_entropy_with_logits(out[va_t], y[va_t]).item()
            vauc = _auc(y[va_t].cpu().numpy(), torch.sigmoid(out[va_t]).cpu().numpy())
        score = vauc if monitor == "auroc" else -vloss
        if score > best["score"] + 1e-6:
            best.update(score=score, state=copy.deepcopy(model.state_dict()), epoch=ep, val_auc=vauc)
            bad = 0
        else:
            bad += 1
            if bad >= patience:
                break
    if best["state"] is not None:
        model.load_state_dict(best["state"])
    return model, best


@torch.no_grad()
def predict(model, data) -> np.ndarray:
    model.eval()
    return torch.sigmoid(model(data.x, data.edge_index, data.edge_attr)).cpu().numpy()


def ece_quantile(y, p, n_bins=10) -> float:
    order = np.argsort(p)
    ece = 0.0
    for b in np.array_split(order, n_bins):
        if len(b):
            ece += len(b) / len(p) * abs(y[b].mean() - p[b].mean())
    return float(ece)


def metrics(y, p, thr=0.5) -> dict:
    yhat = (p >= thr).astype(int)
    tn = int(((yhat == 0) & (y == 0)).sum()); fp = int(((yhat == 1) & (y == 0)).sum())
    return dict(AUROC=_auc(y, p), AUPRC=average_precision_score(y, p), Accuracy=accuracy_score(y, yhat),
                Sensitivity=recall_score(y, yhat, zero_division=0), Specificity=tn / max(tn + fp, 1),
                Precision=precision_score(y, yhat, zero_division=0), F1=f1_score(y, yhat, zero_division=0))


def summarise(df: pd.DataFrame, cols) -> pd.DataFrame:
    return pd.DataFrame({"Mean": df[cols].mean(), "SD": df[cols].std(ddof=1), "Min": df[cols].min(), "Max": df[cols].max()})


# =========================================================================== #
# cross-validation (GAT + baselines)
# =========================================================================== #
def make_gat(cfg):
    h1 = cfg.get("hidden", C.HIDDEN1)
    return GAT(h1=h1, h2=max(h1 // 2, 8), heads=cfg.get("heads", C.HEADS), attn_dropout=cfg.get("dropout", C.DROPOUT),
               feat_dropout=cfg.get("feat_dropout", 0.0), edge_dim=cfg.get("edge_dim"))


def make_splits(info: pd.DataFrame, repeats: int = 1, seed: int = C.SEED_NUMPY) -> list[dict]:
    """Repeated stratified 5-fold CV over the labelled nodes; every fold's 80 % train+val part is split 75/25 -> 60/20/20."""
    lab_idx = np.where(info.label.values >= 0)[0]
    y_lab = info.label.values[lab_idx].astype(int)
    out = []
    for k, (trv_l, te_l) in enumerate(RepeatedStratifiedKFold(n_splits=C.N_FOLDS, n_repeats=repeats, random_state=seed).split(lab_idx, y_lab)):
        trv, te = lab_idx[trv_l], lab_idx[te_l]
        tr, va = train_test_split(trv, test_size=0.25, stratify=info.label.values[trv].astype(int), random_state=seed + k)
        out.append(dict(k=k, rep=k // C.N_FOLDS, fold=k % C.N_FOLDS, trv=trv, tr=tr, va=va, te=te))
    return out


def corrected_resampled_ttest(diff: np.ndarray, n_train: int, n_test: int) -> dict:
    """Nadeau & Bengio (2003) corrected resampled t-test for paired per-fold differences (fold models share training data,
    so the naive variance is too small): t = mean(d) / sqrt((1/k + n_test/n_train) * var(d)),  df = k - 1."""
    d = np.asarray(diff, float)
    k = len(d)
    if k < 2:
        return dict(mean_diff=float(d.mean()), t=np.nan, p=np.nan, ci_low=np.nan, ci_high=np.nan, k=k)
    se = np.sqrt((1.0 / k + n_test / n_train) * d.var(ddof=1))
    t = d.mean() / se if se > 0 else np.inf
    tcrit = stats.t.ppf(0.975, k - 1)
    return dict(mean_diff=float(d.mean()), t=float(t), p=float(2 * stats.t.sf(abs(t), k - 1)),
                ci_low=float(d.mean() - tcrit * se), ci_high=float(d.mean() + tcrit * se), k=k)


def run_cv(data, info, args, cfg=None, baselines=True, verbose=True, gcn=True):
    cfg = cfg or {}
    lab_idx = np.where(info.label.values >= 0)[0]
    y_lab = info.label.values[lab_idx].astype(int)
    n_pos, n_neg = int(y_lab.sum()), int((1 - y_lab).sum())
    if verbose:
        print(f"[cv] labelled nodes: {len(lab_idx)} ({n_pos} drivers / {n_neg} bystanders); "
              f"prevalence = {y_lab.mean():.3f}  (paper: 57/200, 0.22)")
    X_np = info[[f + "_z" for f in C.FEATURES]].values
    raw = {f: info[f].values for f in ("degree", "pagerank")}
    rows, curves, oof = [], {"roc": [], "pr": []}, np.full((args.repeats, len(info)), np.nan)
    first_fold_state = None
    for sp in make_splits(info, args.repeats):
        k, rep, fold, trv, tr, va, te = sp["k"], sp["rep"], sp["fold"], sp["trv"], sp["tr"], sp["va"], sp["te"]
        torch.manual_seed(C.SEED_TORCH + k)
        t0 = time.time()
        gat, best = train_model(make_gat(cfg), data, tr, va, epochs=args.epochs, lr=cfg.get("lr", C.LR),
                                patience=args.patience, monitor=args.monitor)
        p_all = predict(gat, data)
        yte = info.label.values[te].astype(int)
        m = metrics(yte, p_all[te])
        rows.append(dict(repeat=rep, fold=fold, model="GAT", n_trv=len(trv), n_te=len(te), best_epoch=best["epoch"],
                         val_AUROC=best["val_auc"], **m))
        oof[rep, te] = p_all[te]
        if rep == 0:
            fpr, tpr, _ = roc_curve(yte, p_all[te])
            grid = np.linspace(0, 1, 101)
            curves["roc"].append((fold, np.interp(grid, fpr, tpr)))
            pr_, rc_, _ = precision_recall_curve(yte, p_all[te])
            curves["pr"].append((fold, np.interp(grid, rc_[::-1], pr_[::-1])))
        if rep == 0 and fold == 0:
            first_fold_state = dict(model=copy.deepcopy(gat).cpu(), train=tr, val=va, test=te)
        if verbose:
            print(f"[cv] rep{rep} fold{fold}  GAT  AUROC={m['AUROC']:.3f} AUPRC={m['AUPRC']:.3f}  "
                  f"best_epoch={best['epoch']}  val_AUROC={best['val_auc']:.3f}  ({time.time()-t0:.0f}s)")
        if not baselines:
            continue
        # ---- GCN
        if gcn:
            torch.manual_seed(C.SEED_TORCH + k)
            gcn_m, _ = train_model(GCN(), data, tr, va, epochs=args.epochs, patience=args.patience, monitor=args.monitor)
            rows.append(dict(repeat=rep, fold=fold, model="GCN", **metrics(yte, predict(gcn_m, data)[te])))
        # ---- logistic regression, same five z-scored features, no graph
        lr = LogisticRegression(max_iter=2000).fit(X_np[trv], info.label.values[trv].astype(int))
        rows.append(dict(repeat=rep, fold=fold, model="LogReg", **metrics(yte, lr.predict_proba(X_np[te])[:, 1])))
        # ---- single-feature rank baselines (no training: AUROC/AUPRC of the raw score; threshold at the train-set
        #      prevalence-matched quantile for the thresholded metrics)
        for name, key in (("Degree only", "degree"), ("PageRank only", "pagerank")):
            s = raw[key]
            thr_s = np.quantile(s[trv], 1 - info.label.values[trv].mean())
            sc = (s - s.min()) / (s.max() - s.min())
            thr = (thr_s - s.min()) / (s.max() - s.min())
            mm = metrics(yte, sc[te], thr=thr)
            rows.append(dict(repeat=rep, fold=fold, model=name, **mm))
    return pd.DataFrame(rows), curves, oof, first_fold_state, lab_idx


# =========================================================================== #
# hyper-parameter grid (optional; paper Sec 3.6)
# =========================================================================== #
def grid_search(data, info, args) -> dict:
    grid = list(itertools.product((0.001, 0.005, 0.01), (32, 64, 128), (2, 4, 8), (0.3, 0.5, 0.6, 0.7)))
    out = []
    a = copy.copy(args); a.repeats = 1
    for i, (lr, hid, heads, dr) in enumerate(grid):
        df, *_ = run_cv(data, info, a, cfg=dict(lr=lr, hidden=hid, heads=heads, dropout=dr), baselines=False, verbose=False)
        g = df[df.model == "GAT"]
        out.append(dict(lr=lr, hidden=hid, heads=heads, dropout=dr, val_AUROC=g.val_AUROC.mean(), test_AUROC=g.AUROC.mean()))
        print(f"[grid {i+1}/{len(grid)}] lr={lr} hid={hid} heads={heads} drop={dr} -> val AUROC {out[-1]['val_AUROC']:.3f}")
    res = pd.DataFrame(out).sort_values("val_AUROC", ascending=False)
    return res


# =========================================================================== #
# final model, ensemble, bootstrap CI
# =========================================================================== #
def train_final(data, info, epochs, seeds, cfg=None) -> np.ndarray:
    lab_idx = np.where(info.label.values >= 0)[0]
    probs = []
    for s in range(seeds):
        torch.manual_seed(C.SEED_TORCH + s)
        m, _ = train_model(make_gat(cfg or {}), data, lab_idx, None, epochs=epochs, fixed_epochs=True)
        probs.append(predict(m, data))
    return np.vstack(probs)                                                      # (seeds, N)


def bootstrap_ci(P: np.ndarray, n_boot=C.N_BOOT, seed=C.SEED_NUMPY) -> tuple[np.ndarray, np.ndarray]:
    """95 % percentile CI of each protein's mean driver probability, resampling the ensemble members with replacement."""
    rng = np.random.default_rng(seed)
    M = P.shape[0]
    means = np.stack([P[rng.integers(0, M, M)].mean(0) for _ in range(n_boot)])
    return np.percentile(means, 2.5, axis=0), np.percentile(means, 97.5, axis=0)


# =========================================================================== #
# SHAP (KernelExplainer on node-feature vectors, graph held fixed)
# =========================================================================== #
def shap_analysis(model, data, info, train_idx, test_idx, n_explain, nsamples, seed=C.SEED_NUMPY):
    import shap
    model = model.to(DEV).eval()
    rng = np.random.default_rng(seed)
    sel = rng.choice(test_idx, size=min(n_explain, len(test_idx)), replace=False)
    Xc = data.x.cpu()
    background = shap.kmeans(Xc[train_idx].numpy(), 10)
    all_sv = []
    for n_done, v in enumerate(sel, 1):
        # a node's output depends only on its 3-hop neighbourhood (3 GAT layers) -> evaluate on that sub-graph
        sub, sub_ei, mapping, emask = k_hop_subgraph(int(v), 3, data.edge_index.cpu(), relabel_nodes=True, num_nodes=data.num_nodes)
        sub_ei = sub_ei.to(DEV)
        sub_ea = None if data.edge_attr is None else data.edge_attr[emask.to(data.edge_attr.device)]
        x_sub = Xc[sub].clone()
        lv = int(mapping)

        def f(Z, x_sub=x_sub, sub_ei=sub_ei, sub_ea=sub_ea, lv=lv):
            outs = []
            for z in torch.as_tensor(Z, dtype=torch.float32):
                xx = x_sub.clone(); xx[lv] = z
                with torch.no_grad():
                    outs.append(torch.sigmoid(model(xx.to(DEV), sub_ei, sub_ea))[lv].item())
            return np.array(outs)

        ex = shap.KernelExplainer(f, background)
        sv = ex.shap_values(Xc[v].numpy()[None, :], nsamples=nsamples, silent=True)
        all_sv.append(np.asarray(sv).reshape(-1, len(C.FEATURES))[0])
        if n_done % 10 == 0:
            print(f"[shap] {n_done}/{len(sel)} nodes")
    sv = np.vstack(all_sv)
    rng = np.random.default_rng(seed)
    boots = np.stack([np.abs(sv[rng.integers(0, len(sv), len(sv))]).mean(0) for _ in range(C.N_BOOT)])
    tab = pd.DataFrame({"feature": C.FEATURES, "mean_abs_shap": np.abs(sv).mean(0),
                        "ci_low": np.percentile(boots, 2.5, 0), "ci_high": np.percentile(boots, 97.5, 0)}
                       ).sort_values("mean_abs_shap", ascending=False)
    tab["rank"] = np.arange(1, len(tab) + 1)
    return tab, sv, sel


# =========================================================================== #
# main
# =========================================================================== #
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root", default="data")
    ap.add_argument("--epochs", type=int, default=C.EPOCHS)
    ap.add_argument("--patience", type=int, default=50)
    ap.add_argument("--monitor", choices=["auroc", "loss"], default="auroc")
    ap.add_argument("--repeats", type=int, default=1,
                    help="1 = the paper's single 5-fold CV. >1 (e.g. 10) gives 5*repeats paired folds for meaningful "
                         "significance tests (a 5-fold signed-rank test cannot give p < 0.0625).")
    ap.add_argument("--ensemble-seeds", type=int, default=20, help="final-model seeds used for bootstrap CIs")
    ap.add_argument("--rank-by", choices=["ensemble", "single"], default="ensemble")
    ap.add_argument("--grid", action="store_true", help="run the 108-point hyper-parameter grid of Sec 3.6 first")
    ap.add_argument("--shap-n", type=int, default=50)
    ap.add_argument("--shap-nsamples", type=int, default=200)
    ap.add_argument("--skip-shap", action="store_true")
    ap.add_argument("--edge-attr", choices=["none", "string", "abs_r"], default="none",
                    help="none = binary differential graph (default, the manuscript's model); string = STRING score as edge "
                         "feature in the attention; abs_r = |r_AD| of the differential edge as edge feature")
    args = ap.parse_args()

    paths = C.get_paths(args.root)
    res = paths.res
    C.set_seeds()
    print(f"device: {DEV}   torch {torch.__version__}")
    data, info = load_graph(paths.proc, args.edge_attr)
    print(f"graph: {data.num_nodes} nodes, {data.edge_index.size(1)//2} undirected edges, "
          f"{int((torch.bincount(data.edge_index[0], minlength=data.num_nodes)==0).sum())} isolated nodes")

    cfg = {"edge_dim": 1} if args.edge_attr != "none" else {}
    if args.grid:
        g = grid_search(data, info, args)
        g.to_csv(res / "grid_search.csv", index=False)
        b = g.iloc[0]
        cfg = dict(cfg, lr=float(b.lr), hidden=int(b.hidden), heads=int(b.heads), dropout=float(b.dropout))
        print("[grid] best:", cfg)

    # ---------------- cross-validation ---------------------------------------------------------------------------
    cv, curves, oof, first, lab_idx = run_cv(data, info, args, cfg)
    cv.to_csv(res / "cv_fold_metrics.csv", index=False)
    metric_cols = ["AUROC", "AUPRC", "Accuracy", "Sensitivity", "Specificity", "Precision", "F1"]

    gat0 = cv[(cv.model == "GAT") & (cv.repeat == 0)]
    t4 = summarise(gat0, metric_cols)
    t4.to_csv(res / "table4_gat_cv.csv")
    print("\nTable 4 — GAT, 5-fold CV (repeat 0)   paper: AUROC .79±.06  AUPRC .71±.08  Acc .78  Sens .73  Spec .80  Prec .61  F1 .66")
    print(t4.round(3).to_string())

    # ---------------- Table 5: baselines; paired differences vs GAT with Nadeau-Bengio corrected resampled t-test ----------
    prev = float(info.label[info.label >= 0].mean())
    rows = [dict(Method="Random classifier", AUROC=0.5, AUPRC=prev)]
    gat_all = cv[cv.model == "GAT"].sort_values(["repeat", "fold"])
    n_trv, n_te = float(gat_all.n_trv.mean()), float(gat_all.n_te.mean())
    for name in ["Degree only", "PageRank only", "LogReg", "GCN"]:
        d = cv[cv.model == name].sort_values(["repeat", "fold"])
        d0 = d[d.repeat == 0]
        tt = corrected_resampled_ttest(gat_all.AUROC.values - d.AUROC.values, n_trv, n_te)
        tp = corrected_resampled_ttest(gat_all.AUPRC.values - d.AUPRC.values, n_trv, n_te)
        rows.append(dict(Method=name,
                         AUROC=f"{d0.AUROC.mean():.3f} ± {d0.AUROC.std(ddof=1):.3f}",
                         AUPRC=f"{d0.AUPRC.mean():.3f} ± {d0.AUPRC.std(ddof=1):.3f}",
                         dAUROC_GAT_minus_method=tt["mean_diff"], dAUROC_CI95=f"[{tt['ci_low']:.3f}, {tt['ci_high']:.3f}]",
                         p_corrected_t_AUROC=tt["p"], dAUPRC_GAT_minus_method=tp["mean_diff"],
                         dAUPRC_CI95=f"[{tp['ci_low']:.3f}, {tp['ci_high']:.3f}]", p_corrected_t_AUPRC=tp["p"], n_folds=tt["k"]))
    t5 = pd.DataFrame(rows)
    t5.to_csv(res / "table5_baselines.csv", index=False)
    print("\nTable 5 — baselines (AUROC/AUPRC: mean ± SD over the first 5-fold repeat; differences use all folds)")
    print(t5.to_string(index=False))
    print(f"NB: corrected resampled t-test over {len(gat_all)} paired folds (Nadeau & Bengio 2003). Fold models share training "
          f"data, so p-values remain approximate; prefer the CIs, and use --repeats 10 for stable estimates.")

    # ---------------- calibration + confusion matrix on pooled out-of-fold predictions ------------------------------
    oof0 = oof[0, lab_idx]
    y_lab = info.label.values[lab_idx].astype(int)
    ok = ~np.isnan(oof0)
    pooled = metrics(y_lab[ok], oof0[ok])
    pt, pp = calibration_curve(y_lab[ok], oof0[ok], n_bins=10, strategy="quantile")
    cal = dict(brier=float(brier_score_loss(y_lab[ok], oof0[ok])), ece=ece_quantile(y_lab[ok], oof0[ok]),
               pooled_oof=pooled, calib_true=pt.tolist(), calib_pred=pp.tolist())
    yhat = (oof0[ok] >= 0.5).astype(int)
    cal["confusion"] = dict(TP=int(((yhat == 1) & (y_lab[ok] == 1)).sum()), FN=int(((yhat == 0) & (y_lab[ok] == 1)).sum()),
                            TN=int(((yhat == 0) & (y_lab[ok] == 0)).sum()), FP=int(((yhat == 1) & (y_lab[ok] == 0)).sum()))
    (res / "calibration.json").write_text(json.dumps(cal, indent=2))
    print(f"\n[calibration] Brier={cal['brier']:.3f} (paper .085)  ECE={cal['ece']:.3f} (paper .038/.046)  confusion@0.5={cal['confusion']}")
    np.savez(res / "cv_curves.npz", grid=np.linspace(0, 1, 101),
             roc=np.vstack([c for _, c in curves["roc"]]), pr=np.vstack([c for _, c in curves["pr"]]), oof=oof, lab_idx=lab_idx)

    # ---------------- final model(s) + predictions for every protein -----------------------------------------------
    final_epochs = int(max(20, np.median(gat_all.best_epoch)))
    print(f"\n[final] retraining on all {len(lab_idx)} labelled nodes for {final_epochs} epochs (median CV best epoch), "
          f"{args.ensemble_seeds} seeds")
    P = train_final(data, info, final_epochs, args.ensemble_seeds, cfg)
    lo, hi = bootstrap_ci(P)
    out = info[["gene", "label"]].copy()
    out["prob_single"] = P[0]
    out["prob_ensemble"] = P.mean(0)
    out["ci_low"], out["ci_high"] = lo, hi
    with np.errstate(all="ignore"), warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        out["oof_prob"] = np.nanmean(oof, axis=0)                                # honest estimate for labelled nodes
    out["degree"] = info.degree.values
    score = "prob_ensemble" if args.rank_by == "ensemble" else "prob_single"
    out = out.sort_values(score, ascending=False).reset_index(drop=True)
    out.to_csv(res / "predictions_all_nodes.csv", index=False)
    novel = out[out.label != 1]
    novel.head(10).to_csv(res / "table6_top10_novel.csv", index=False)
    novel.head(50).to_csv(res / "supp_table_S4_top50.csv", index=False)
    print("\nTable 6 — top-10 non-positive proteins (paper: MARK4, CSNK1D, HSP90AA1, PIN1, GSK3B, UCHL1, YWHAZ, CDK5 ...)")
    print(novel.head(10)[["gene", score, "ci_low", "ci_high", "label"]].round(3).to_string(index=False))
    print("\n[final] in-sample probabilities of the labelled genes are optimistic; use `oof_prob` for them.")

    # ---------------- SHAP ----------------------------------------------------------------------------------------
    if not args.skip_shap:
        print("\n[shap] KernelExplainer on fold-0 model ...")
        tab, sv, sel = shap_analysis(first["model"], data, info, first["train"], first["test"],
                                     args.shap_n, args.shap_nsamples)
        tab.to_csv(res / "table8_shap.csv", index=False)
        np.savez(res / "shap_values.npz", shap=sv, nodes=sel, features=np.array(C.FEATURES))
        print("Table 8 — mean |SHAP|   paper: PageRank .22, fold-change .18, degree .15, betweenness .09, clustering .04")
        print(tab.round(3).to_string(index=False))

    torch.save({"final_epochs": final_epochs, "cfg": cfg}, res / "run_config.pt")
    print(f"\nStage 2 finished -> {res}")


if __name__ == "__main__":
    main()
