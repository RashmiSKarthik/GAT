#!/usr/bin/env python
"""
Stage 3 (optional) — GO molecular-function enrichment of the top predictions (Sec 3.7 / Table 9),
probability-by-category summary (Table 10) and publication figures (Figs 1-5, SHAP bar).

GO enrichment = one-sided hypergeometric test with Benjamini-Hochberg FDR over all tested terms, annotations propagated to
ancestor terms (the same statistics as goatools.GOEnrichmentStudy with propagate_counts=True, methods=['fdr_bh']).
goatools is used only to parse the ontology.

    python stage3_enrichment_figures.py --root data --obo raw/go-basic.obo --gaf raw/goa_human.gaf.gz
"""
from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

import common as C

plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 150})


# =========================================================================== #
# GO enrichment
# =========================================================================== #
def read_gaf(path: Path, aspect: str) -> dict[str, set[str]]:
    op = gzip.open if str(path).endswith(".gz") else open
    ann: dict[str, set[str]] = {}
    with op(path, "rt") as f:
        for line in f:
            if line.startswith("!"):
                continue
            c = line.rstrip("\n").split("\t")
            if len(c) < 9 or c[8] != aspect or "NOT" in c[3]:
                continue
            ann.setdefault(c[2], set()).add(c[4])
    return ann


def go_enrichment(study: list[str], population: list[str], obo: Path, gaf: Path, aspect="F",
                  min_study=2, alpha=0.05) -> pd.DataFrame:
    from goatools.obo_parser import GODag
    dag = GODag(str(obo), load_obsolete=False, prt=None)
    raw = read_gaf(gaf, aspect)
    anc_cache: dict[str, set[str]] = {}

    def prop(terms):
        out = set()
        for t in terms:
            if t not in dag:
                continue
            if t not in anc_cache:
                anc_cache[t] = {t} | dag[t].get_all_parents()
            out |= anc_cache[t]
        return out

    pop = set(population)
    gene2go = {g: prop(raw.get(g, ())) for g in pop}
    annotated = [g for g in pop if gene2go[g]]
    study = [g for g in study if g in pop and gene2go[g]]
    N, n = len(annotated), len(study)
    from collections import Counter
    pc = Counter(t for g in annotated for t in gene2go[g])
    sc = Counter(t for g in study for t in gene2go[g])
    rows = []
    for t, k in sc.items():
        if k < min_study:
            continue
        K = pc[t]
        p = stats.hypergeom.sf(k - 1, N, K, n)
        rows.append(dict(go_id=t, name=dag[t].name, study_count=k, pop_count=K,
                         study_frac=k / n, pop_frac=K / N, fold_enrichment=(k / n) / (K / N), p=p))
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    df["fdr"] = multipletests(df.p, method="fdr_bh")[1]
    return df.sort_values("p").reset_index(drop=True).assign(significant=lambda d: d.fdr < alpha)


# =========================================================================== #
# tables
# =========================================================================== #
def table10(pred: pd.DataFrame, top_novel: pd.DataFrame, score: str) -> pd.DataFrame:
    # labelled nodes: use out-of-fold probabilities (final-model predictions on them are in-sample)
    groups = {
        "Known AD genes (out-of-fold)": pred.loc[pred.label == 1, "oof_prob"],
        "Top-10 novel candidates": top_novel[score],
        "Negative controls (out-of-fold)": pred.loc[pred.label == 0, "oof_prob"],
        "Unlabelled proteins": pred.loc[pred.label == -1, score],
    }
    rows = [dict(group=k, n=len(v), mean=v.mean(), sd=v.std(), median=v.median()) for k, v in groups.items()]
    t = pd.DataFrame(rows)
    ks = list(groups)
    ps = {f"{a} vs {b}": stats.mannwhitneyu(groups[a], groups[b])[1] for i, a in enumerate(ks) for b in ks[i + 1:]}
    return t, pd.Series(ps, name="p_mannwhitney")


# =========================================================================== #
# figures
# =========================================================================== #
def save(fig, path_stem: Path):
    fig.tight_layout()
    fig.savefig(str(path_stem) + ".png", dpi=300)
    fig.savefig(str(path_stem) + ".pdf")
    plt.close(fig)


def fig_cv_curves(res: Path, out: Path):
    z = np.load(res / "cv_curves.npz")
    g = z["grid"]
    fig, ax = plt.subplots(1, 2, figsize=(7.2, 3.2))
    for a, key, xl, yl in ((ax[0], "roc", "False-positive rate", "True-positive rate"),
                           (ax[1], "pr", "Recall", "Precision")):
        for c in z[key]:
            a.plot(g, c, color="grey", alpha=.35, lw=.8)
        m, s = z[key].mean(0), z[key].std(0)
        a.plot(g, m, color="C0", lw=2, label="GAT (mean ± SD)")
        a.fill_between(g, np.clip(m - s, 0, 1), np.clip(m + s, 0, 1), color="C0", alpha=.2)
        a.set_xlabel(xl); a.set_ylabel(yl)
    ax[0].plot([0, 1], [0, 1], "k--", lw=.8, label="random"); ax[0].legend(frameon=False)
    ax[0].set_title("A  ROC (5-fold CV)", loc="left"); ax[1].set_title("B  Precision-recall", loc="left")
    save(fig, out / "fig3_cv_curves")


def fig_calibration(res: Path, out: Path):
    cal = json.loads((res / "calibration.json").read_text())
    cv = pd.read_csv(res / "cv_fold_metrics.csv")
    g = cv[(cv.model == "GAT") & (cv.repeat == 0)]
    fig, ax = plt.subplots(1, 2, figsize=(7.2, 3.2))
    ax[0].plot([0, 1], [0, 1], "k--", lw=.8)
    ax[0].plot(cal["calib_pred"], cal["calib_true"], "o-", color="C0")
    ax[0].set_xlabel("Mean predicted probability"); ax[0].set_ylabel("Observed fraction of drivers")
    ax[0].set_title(f"A  Calibration (ECE {cal['ece']:.3f}, Brier {cal['brier']:.3f})", loc="left")
    cols = ["AUROC", "AUPRC", "Accuracy", "Sensitivity", "Specificity", "Precision", "F1"]
    ax[1].bar(cols, g[cols].mean(), yerr=g[cols].std(ddof=1), capsize=3, color="C0", alpha=.85)
    ax[1].set_ylim(0, 1); ax[1].tick_params(axis="x", rotation=40); ax[1].set_title("B  Fold-wise metrics", loc="left")
    save(fig, out / "fig4_calibration_metrics")


def fig_categories(pred: pd.DataFrame, top_novel: pd.DataFrame, score: str, out: Path):
    data = [pred.loc[pred.label == 1, "oof_prob"], top_novel[score], pred.loc[pred.label == 0, "oof_prob"],
            pred.loc[pred.label == -1, score]]
    fig, ax = plt.subplots(figsize=(4.6, 3.3))
    ax.boxplot(data, showfliers=False, patch_artist=True, boxprops=dict(facecolor="#cfe3f5"))
    ax.set_xticklabels(["Known AD\n(OOF)", "Top-10\nnovel", "Negatives\n(OOF)", "Unlabelled"])
    ax.set_ylabel("Predicted driver probability")
    save(fig, out / "fig5_probability_by_category")


def fig_network(proc: Path, out: Path):
    feat = pd.read_csv(proc / "node_features.csv")
    ef = pd.read_csv(proc / "edges_full.csv.gz")
    fig, ax = plt.subplots(1, 3, figsize=(10, 3.1))
    bins = np.linspace(-1, 1, 61)
    ax[0].hist(ef.r_ctrl, bins, density=True, alpha=.55, label="Control")
    ax[0].hist(ef.r_ad, bins, density=True, alpha=.55, label="AD")
    ax[0].set_xlabel("Pearson r (STRING edges)"); ax[0].set_ylabel("Density"); ax[0].legend(frameon=False)
    ax[0].set_title("A  Edge correlations", loc="left")
    cat = ef.category.value_counts()
    ax[1].bar(["AD-exclusive", "Strengthened\nin AD", "Not\nenriched"],
              [cat.get("AD_exclusive", 0), cat.get("strengthened_in_AD", 0), cat.get("not_enriched", 0)], color=["C3", "C1", "grey"])
    ax[1].set_ylabel("Edges"); ax[1].set_title("B  Differential edges", loc="left")
    deg_full = pd.concat([ef.source, ef.target]).value_counts().reindex(feat.gene).fillna(0).values
    for d, lab_ in ((deg_full, "Full STRING"), (feat.degree.values, "Differential")):
        d = np.sort(d[d > 0])[::-1]
        ax[2].loglog(d, np.arange(1, len(d) + 1) / len(d), label=lab_)
    ax[2].set_xlabel("Degree k"); ax[2].set_ylabel("P(K ≥ k)"); ax[2].legend(frameon=False)
    ax[2].set_title("C  Degree distribution", loc="left")
    save(fig, out / "fig1_2_network_summary")


def fig_shap(res: Path, out: Path):
    f = res / "table8_shap.csv"
    if not f.exists():
        return
    t = pd.read_csv(f).sort_values("mean_abs_shap")
    fig, ax = plt.subplots(figsize=(4.2, 2.6))
    ax.barh(t.feature, t.mean_abs_shap, xerr=[t.mean_abs_shap - t.ci_low, t.ci_high - t.mean_abs_shap], color="C0", capsize=3)
    ax.set_xlabel("Mean |SHAP| (probability units)")
    save(fig, out / "fig_shap_importance")


# =========================================================================== #
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root", default="data")
    ap.add_argument("--obo", default=None)
    ap.add_argument("--gaf", default=None)
    ap.add_argument("--top-n", type=int, default=100)
    ap.add_argument("--min-prob", type=float, default=0.60)
    ap.add_argument("--aspect", default="F", help="F = molecular function (Table 9), P = process, C = component")
    ap.add_argument("--rank-by", choices=["ensemble", "single"], default="ensemble")
    args = ap.parse_args()

    paths = C.get_paths(args.root)
    res, proc = paths.res, paths.proc
    figdir = res / "figures"; figdir.mkdir(exist_ok=True)
    score = "prob_ensemble" if args.rank_by == "ensemble" else "prob_single"
    pred = pd.read_csv(res / "predictions_all_nodes.csv")
    novel = pred[pred.label != 1].sort_values(score, ascending=False)
    top10 = novel.head(10)

    # ---- Table 10
    t10, pv = table10(pred, top10, score)
    t10.to_csv(res / "table10_probability_by_category.csv", index=False)
    pv.to_csv(res / "table10_pvalues.csv")
    print("Table 10 — predicted probability by category (paper: .72 / .74 / .24 / .31)")
    print(t10.round(3).to_string(index=False)); print(pv.to_string())

    # ---- Table 9
    if args.obo and args.gaf:
        study = novel[novel[score] >= args.min_prob].head(args.top_n).gene.tolist()
        print(f"[go] study set: {len(study)} proteins (top {args.top_n} non-positive with p >= {args.min_prob})")
        feat = pd.read_csv(proc / "node_features.csv")
        go = go_enrichment(study, feat.gene.tolist(), Path(args.obo), Path(args.gaf), args.aspect)
        go.to_csv(res / "table9_go_enrichment.csv", index=False)
        print(go.head(10).round(4).to_string(index=False) if len(go) else "no terms with >= 2 study genes")
    else:
        print("[go] skipped (pass --obo and --gaf)")

    # ---- figures
    for fn, a in ((fig_network, (proc, figdir)), (fig_cv_curves, (res, figdir)), (fig_calibration, (res, figdir)),
                  (fig_categories, (pred, top10, score, figdir)), (fig_shap, (res, figdir))):
        try:
            fn(*a)
        except Exception as e:
            print(f"[fig] {fn.__name__} failed: {e!r}")
    print(f"Stage 3 finished -> {res}")


if __name__ == "__main__":
    main()
